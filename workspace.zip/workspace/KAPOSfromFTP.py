import os
import datetime
import ftplib
import boto3
import shutil
import glob

# ======================================
# AWS Lambda 및 S3용으로 변환 (최종 업데이트)
# ======================================

# ================================
# S3 버킷 이름 및 지역 설정
# ================================
S3_BUCKET_NAME = "kihub-transfer-bucket-dev"
S3_REGION = "ap-southeast-1"

# 로컬 경로를 Lambda의 /tmp 디렉터리 하위 경로로 매핑
TOOLS_DIR = "/tmp/Tools"
POS_DATA_DIR = "/tmp/sFTP_POS/POS_Data"
LOG_DIR = os.path.join(TOOLS_DIR, "Log")

# ================================
# Boto3 클라이언트 설정
# ================================
s3_client = boto3.client('s3', region_name=S3_REGION)

# ================================
# FTP 다운로드 및 S3 업로드 함수
# ================================
def ftp_download_to_s3(host, user, password, remote_patterns, local_dir, s3_prefix, log_file):
    """
    FTP 서버에서 파일을 Lambda의 로컬 임시 디렉터리(tmp)로 다운로드한 후,
    S3 버킷으로 업로드하고 오류 발생 시 로그 파일을 생성하는 함수
    """
    os.makedirs(local_dir, exist_ok=True)
    
    try:
        with ftplib.FTP(host) as ftp:
            ftp.login(user=user, passwd=password)
            print(f"[FTP 접속 성공] {host}")
            
            ftp.sendcmd("TYPE I")  # 바이너리 모드 설정

            for pattern in remote_patterns:
                try:
                    # 원격 파일 목록 가져오기
                    filenames = ftp.nlst(pattern)
                except ftplib.error_perm:
                    filenames = []
                    print(f"[FTP] {pattern} 패턴에 해당하는 파일이 없습니다.")
                
                for filename in filenames:
                    local_file_path = os.path.join(local_dir, os.path.basename(filename))
                    s3_key = os.path.join(s3_prefix, os.path.basename(filename)).replace('\\', '/')

                    with open(local_file_path, "wb") as f:
                        ftp.retrbinary(f"RETR {filename}", f.write)
                    
                    print(f"[다운로드 성공] {filename} -> {local_file_path}")
                    
                    # 다운로드 완료 후 S3에 업로드
                    s3_client.upload_file(local_file_path, S3_BUCKET_NAME, s3_key)
                    print(f"[S3 업로드 성공] {local_file_path} -> s3://{S3_BUCKET_NAME}/{s3_key}")
        
        ftp.quit()
        print(f"[FTP 연결 종료] {host}")
    except Exception as e:
        log_s3_key = os.path.basename(pattern).replace('\\', '/').replace('/tmp/', '')
        error_message = f"[{datetime.now()}] [FTP 오류] {host} : {e}\n"

        with open(log_file, "a", encoding="utf-8") as f:
            f.write(error_message)
            
        print(error_message)
        s3_client.upload_file(log_file, S3_BUCKET_NAME, log_s3_key)

# ---

# ================================
# S3 파일 복사 함수
# ================================
def s3_copy_files(source_prefix, target_prefix, pattern):
    """
    S3의 특정 경로(source_prefix)에 있는 파일을 다른 S3 경로(target_prefix)로 복사
    """
    paginator = s3_client.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=S3_BUCKET_NAME, Prefix=source_prefix)

    for page in pages:
        if 'Contents' in page:
            for obj in page['Contents']:
                source_key = obj['Key']
                # glob 패턴과 일치하는 파일만 복사
                if glob.fnmatch.fnmatch(os.path.basename(source_key), pattern):
                    target_key = os.path.join(target_prefix, os.path.basename(source_key)).replace('\\', '/')
                    try:
                        s3_client.copy_object(
                            Bucket=S3_BUCKET_NAME,
                            CopySource={'Bucket': S3_BUCKET_NAME, 'Key': source_key},
                            Key=target_key
                        )
                        print(f"[S3 복사 성공] {source_key} -> {target_key}")
                    except Exception as e:
                        print(f"[S3 복사 실패] {source_key} : {e}")

# ---

# ================================
# S3 파일 이동 함수
# ================================
def s3_move_files(source_prefix, target_prefix, pattern):
    """
    S3의 특정 경로에 있는 파일을 다른 S3 경로로 이동 (복사 후 원본 삭제)
    """
    paginator = s3_client.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=S3_BUCKET_NAME, Prefix=source_prefix)

    for page in pages:
        if 'Contents' in page:
            for obj in page['Contents']:
                source_key = obj['Key']
                # glob 패턴과 일치하는 파일만 이동
                if glob.fnmatch.fnmatch(os.path.basename(source_key), pattern):
                    target_key = os.path.join(target_prefix, os.path.basename(source_key)).replace('\\', '/')
                    try:
                        # 복사 작업
                        s3_client.copy_object(
                            Bucket=S3_BUCKET_NAME,
                            CopySource={'Bucket': S3_BUCKET_NAME, 'Key': source_key},
                            Key=target_key
                        )
                        # 원본 삭제
                        s3_client.delete_object(Bucket=S3_BUCKET_NAME, Key=source_key)
                        print(f"[S3 이동 성공] {source_key} -> {target_key}")
                    except Exception as e:
                        print(f"[S3 이동 실패] {source_key} : {e}")

# ---

# ================================
# S3 오래된 파일 삭제 함수
# ================================
def s3_delete_old_files(s3_prefix, days):
    """
    S3 특정 경로에서 지정된 일수보다 오래된 파일을 삭제
    """
    # UTC 기준으로 지정된 일수 이전의 날짜/시간 계산
    cutoff = datetime.now(datetime.timezone.utc) - datetime.timedelta(days=days)
    
    paginator = s3_client.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=S3_BUCKET_NAME, Prefix=s3_prefix)

    for page in pages:
        if 'Contents' in page:
            for obj in page['Contents']:
                last_modified = obj['LastModified']
                # 파일의 마지막 수정 시간이 기준 날짜보다 오래되었는지 확인
                if last_modified.timestamp() < cutoff.timestamp():
                    try:
                        s3_client.delete_object(Bucket=S3_BUCKET_NAME, Key=obj['Key'])
                        print(f"[S3 삭제 성공] {obj['Key']}")
                    except Exception as e:
                        print(f"[S3 삭제 실패] {obj['Key']} : {e}")

# ---

# ================================
# 메인 Lambda 핸들러 함수
# ================================
def lambda_handler(event, context):
    print("===== CU FTP 다운로드 시작 =====")
    
    # 로컬 경로 구조 생성을 위해 /tmp 디렉터리에 폴더 생성
    os.makedirs(LOG_DIR, exist_ok=True)
    
    # FTP 다운로드 및 S3 업로드
    ftp_download_to_s3(
        host="121.140.152.136",
        user="pmk",
        password="PMK",
        remote_patterns=[
            "FM_2025*.TXT",
            "PM_CU_TAX_2025*.txt",
            "PM_CU_INVENTORY_2025*.TXT"
        ],
        local_dir=os.path.join(POS_DATA_DIR, "FTP_POS", "POS_CU"),
        s3_prefix="sFTP_POS/POS_Data/FTP_POS/POS_CU",
        log_file=os.path.join(LOG_DIR, "ftp_cu.log")
    )

    print("\n===== GS25 작업 =====")
    # GS25 파일 S3 복사
    s3_copy_files(
        source_prefix="sFTP_POS/POS_Data/POS_GS25",
        target_prefix="sFTP_POS/POS_Data/FTP_POS/POS_GS25",
        pattern="PMI_D20*.gz"
    )
    s3_copy_files(
        source_prefix="sFTP_POS/POS_Data/POS_GS25",
        target_prefix="sFTP_POS/POS_Data/FTP_POS/POS_GS25",
        pattern="PM_GS_TAX_2*.gz"
    )
    s3_copy_files(
        source_prefix="sFTP_POS/POS_Data/POS_GS25",
        target_prefix="sFTP_POS/POS_Data/FTP_POS/POS_GS25",
        pattern="PM_GS_INVENTORY_2*.gz"
    )

    # GS25 파일 S3 이동
    s3_move_files(
        source_prefix="sFTP_POS/POS_Data/POS_GS25",
        target_prefix="sFTP_POS/POS_Data/POS_OTHERS",
        pattern="PMI_D20*.gz"
    )
    s3_move_files(
        source_prefix="sFTP_POS/POS_Data/POS_GS25",
        target_prefix="sFTP_POS/POS_Data/POS_OTHERS",
        pattern="PM_GS_TAX_2*.gz"
    )
    s3_move_files(
        source_prefix="sFTP_POS/POS_Data/POS_GS25",
        target_prefix="sFTP_POS/POS_Data/POS_OTHERS",
        pattern="PM_GS_INVENTORY_2*.gz"
    )

    print("\n===== POK 작업 =====")
    s3_move_files(
        source_prefix="sFTP_POS/POS_Data/POS_POK",
        target_prefix="sFTP_POS/POS_Data/POS_EMart",
        pattern="PM_POK_2*.txt"
    )
    # 14일보다 오래된 파일 삭제
    s3_delete_old_files("sFTP_POS/POS_Data/POS_POK", 14)

    print("\n===== E-Commerce SRQ04208833 작업 =====")
    s3_move_files(
        source_prefix="sFTP_POS/POS_Data/ECOM_Data/Upload",
        target_prefix="sFTP_POS/POS_Data/POS_OTHERS",
        pattern="ecomdata.csv"
    )

    print("\n===== 3PECOM 작업 =====")
    s3_copy_files(
        source_prefix="sFTP_POS/POS_Data/3PECOM_Data/3PEcomsales",
        target_prefix="Tools/Backup/3PECOM",
        pattern="3rdpartyecom*.csv"
    )
    s3_move_files(
        source_prefix="sFTP_POS/POS_Data/3PECOM_Data/3PEcomsales",
        target_prefix="sFTP_POS/POS_Data/POS_OTHERS",
        pattern="3rdpartyecom*.csv"
    )
    
    # 모든 작업 완료 후 임시 디렉터리 정리
    shutil.rmtree(os.path.join("/tmp", "sFTP_POS"), ignore_errors=True)
    shutil.rmtree(os.path.join("/tmp", "Tools"), ignore_errors=True)
    print("\n모든 임시 디렉터리가 정리되었습니다.")

    print("\n모든 S3 작업이 완료되었습니다!")

    return {
        'statusCode': 200,
        'body': 'Lambda function execution complete.'
    }