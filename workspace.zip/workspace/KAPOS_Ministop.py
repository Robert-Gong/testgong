"""
Ministop FTPS 다운로드 (Lambda용)
 - FTPS (FTP over TLS) 사용
 - Lambda 전용 /tmp 경로 사용
 - 다운로드 후 S3 업로드
 - 로그도 S3에 저장
"""

import os
import ftplib
import boto3
from ftplib import FTP, error_perm, all_errors
from datetime import datetime, timedelta

# -----------------------------
# 설정
# -----------------------------
HOST = "218.234.59.18"
PORT = 995
USERNAME = "philipmorris"
PASSWORD = "philipmorris"

# Lambda 전용 경로
BASE_DIR = "/tmp/sFTP_POS/POS_Data/FTP_POS/POS_MiniStop"
LOG_FILE = "/tmp/Tools/Log/ftp_Ministop.log"

os.makedirs(BASE_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

# S3 설정
S3_BUCKET = "kihub-transfer-bucket-dev"
S3_PREFIX = "sFTP_POS/POS_Data/FTP_POS/POS_MiniStop/"  # 다운로드 파일 업로드 경로
S3_PREFIX_LOG = "Tools/Log/"  # 로그 파일 업로드 경로
s3_client = boto3.client("s3", region_name="ap-southeast-1")

# -----------------------------
# 날짜 계산
# -----------------------------
today = datetime.today()
yesterday = today - timedelta(days=1)

TODAY = today.strftime("%Y%m%d")
YESTERDAY = yesterday.strftime("%Y%m%d")

FILES_TO_GET = [
    f"DAILYMINISTOP{YESTERDAY}.txt",
    f"DAILYMINISTOP{TODAY}.txt",
]

# -----------------------------
# 로깅 유틸
# -----------------------------
def log(msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")

# -----------------------------
# S3 업로드
# -----------------------------
def upload_to_s3(local_path: str, s3_key: str):
    try:
        s3_client.upload_file(local_path, S3_BUCKET, s3_key)
        log(f"[S3 UPLOAD] {local_path} → s3://{S3_BUCKET}/{s3_key}")
        os.remove(local_path)  # Lambda tmp 용량 확보 위해 삭제
    except Exception as e:
        log(f"[S3 FAIL] {local_path} → {s3_key} ({e})")

# -----------------------------
# 원격 파일 존재 확인
# -----------------------------
def remote_exists(ftp: FTP, filename: str) -> bool:
    try:
        ftp.size(filename)
        return True
    except error_perm:
        return False
    except Exception:
        try:
            return len(ftp.nlst(filename)) > 0
        except Exception:
            return False

# -----------------------------
# FTPS 다운로드
# -----------------------------
def download_files():
    target_yesterday_local = os.path.join(BASE_DIR, FILES_TO_GET[0])
    if os.path.exists(target_yesterday_local):
        log(f"[SKIP] 이미 존재: {target_yesterday_local}")
        return

    try:
        log(f"FTPS 접속 시도: {HOST}:{PORT} (user={USERNAME})")
        ftp = FTP(encoding='euc-kr')
        ftp.connect(HOST, PORT, timeout=30)
        ftp.login(USERNAME, PASSWORD)
       
        ftp.set_pasv(True)

        for name in FILES_TO_GET:
            local_path = os.path.join(BASE_DIR, name)
            if os.path.exists(local_path):
                log(f"[SKIP] 로컬에 이미 존재: {local_path}")
                continue
            if not remote_exists(ftp, name):
                log(f"[MISS] 원격에 없음: {name}")
                continue

            try:
                with open(local_path, "wb") as f:
                    log(f"[DOWN] {name} -> {local_path} 시작")
                    ftp.retrbinary(f"RETR {name}", f.write)
                log(f"[OK] 다운로드 완료: {local_path}")

                # S3 업로드 후 삭제
                s3_key = f"{S3_PREFIX}{name}"
                upload_to_s3(local_path, s3_key)

            except all_errors as e:
                if os.path.exists(local_path):
                    os.remove(local_path)
                log(f"[FAIL] 다운로드 실패: {name} ({e})")

        try:
            ftp.quit()
        except Exception:
            try:
                ftp.close()
            except Exception:
                pass
        log("FTPS 연결 종료")

    except Exception as e:
        log(f"[ERROR] FTPS 연결/작업 중 오류: {e}")

# -----------------------------
# Lambda 핸들러
# -----------------------------
def lambda_handler(event, context):
    log(f"TODAY={TODAY}  YESTERDAY={YESTERDAY}")
    download_files()
    # 로그 S3 업로드
    upload_to_s3(LOG_FILE, f"{S3_PREFIX_LOG}ftp_Ministop_{YESTERDAY}.log")
    log("작업 종료")
    return {"status": "success"}
