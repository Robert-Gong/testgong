import os
import boto3
from datetime import datetime, timedelta
from pathlib import Path

# ================================
# S3 버킷 및 지역 설정
# ================================
S3_BUCKET_NAME = "kihub-transfer-bucket-dev"
S3_REGION = "ap-southeast-1"

# ================================
# Boto3 클라이언트 설정
# ================================
s3_client = boto3.client('s3', region_name=S3_REGION)

# -----------------------------
# 로그 기록 (CloudWatch Logs 사용)
# -----------------------------
def write_log(msg: str, ex: Exception = None):
    """
    AWS CloudWatch Logs에 로그를 기록합니다.
    로컬 파일 대신 CloudWatch에 자동으로 기록되므로 별도의 파일 관리가 필요 없습니다.
    """
    if msg:
        print(f"[메시지] {msg}")
    if ex:
        print(f"[오류 유형] {type(ex).__name__}")
        print(f"[오류 내용] {str(ex)}")

# -----------------------------
# S3 객체 복사
# -----------------------------
def fn_copy_s3_objects(source_prefix, target_prefix, target_date=None):
    """
    S3 특정 경로의 객체를 다른 S3 경로로 복사합니다.
    
    :param source_prefix: 원본 S3 경로 (예: "sFTP_POS/POS_Data/FTP_POS/POS_CU")
    :param target_prefix: 대상 S3 경로 (예: "sFTP_POS/POS_Data/POS_OTHERS")
    :param target_date: 지정된 시간 이후에 수정된 파일만 복사 (datetime 객체)
    """
    print(f"[{datetime.now().strftime('%Y%m%d %H:%M:%S')}] {source_prefix} 에서 {target_prefix} 로 파일 복사 시작")

    paginator = s3_client.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=S3_BUCKET_NAME, Prefix=source_prefix)

    for page in pages:
        if 'Contents' in page:
            for obj in page['Contents']:
                source_key = obj['Key']
                
                # S3 폴더 자체는 복사 대상에서 제외
                if source_key.endswith('/'):
                    continue

                try:
                    # 파일의 마지막 수정 시간을 확인하여 조건에 맞는지 검사
                    last_modified = obj['LastModified']
                    if target_date and last_modified.timestamp() <= target_date.timestamp():
                        print(f"Old File: {os.path.basename(source_key)}")
                        continue

                    # S3 객체 복사
                    target_key = os.path.join(target_prefix, os.path.basename(source_key)).replace('\\', '/')
                    
                    s3_client.copy_object(
                        Bucket=S3_BUCKET_NAME,
                        CopySource={'Bucket': S3_BUCKET_NAME, 'Key': source_key},
                        Key=target_key
                    )
                    print(f"복사 성공: {os.path.basename(source_key)} -> {target_key}")

                except Exception as e:
                    write_log(f"파일 복사 오류: {source_key}", e)

# -----------------------------
# 메인 Lambda 핸들러
# -----------------------------
def lambda_handler(event, context):
    print("========================")
    print("POS Files Copy Ver 1.0.0")
    print("========================")
    
    # 15분 전 시간을 계산하여 최근 파일만 처리하도록 설정
    target_date = datetime.now() - timedelta(minutes=15)
    
    # 기존 로컬 경로를 S3 객체 경로로 매핑
    paths_to_copy = {
        "CU": ("sFTP_POS/POS_Data/FTP_POS/POS_CU", "sFTP_POS/POS_Data/POS_OTHERS"),
        "7Elelven": ("sFTP_POS/POS_Data/FTP_POS/POS_SevenEleven", "sFTP_POS/POS_Data/POS_OTHERS"),
        "Ministop": ("sFTP_POS/POS_Data/FTP_POS/POS_MiniStop", "sFTP_POS/POS_Data/POS_OTHERS"),
        "GS25": ("sFTP_POS/POS_Data/FTP_POS/POS_GS25", "sFTP_POS/POS_Data/POS_OTHERS"),
        "WithMe": ("sFTP_POS/POS_Data/FTP_POS/POS_WithMe", "sFTP_POS/POS_Data/POS_OTHERS")
    }

    # S3 경로별 파일 복사
    for key, (source_path, target_path) in paths_to_copy.items():
        print(f"\n===== {key} 파일 복사 시작 =====")
        fn_copy_s3_objects(source_path, target_path, target_date)
    
    write_log("모든 파일 복사 작업 완료")

    return {
        'statusCode': 200,
        'body': 'Lambda function execution complete.'
    }