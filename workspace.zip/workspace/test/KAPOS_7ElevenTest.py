import ftplib
import os
import datetime
import boto3
import gzip

# ======================================
# Python 변환 (7Eleven 전용, Lambda /tmp 사용)
# ======================================

# ================================
# S3 설정
# ================================
S3_BUCKET = "kihub-transfer-bucket-dev"
S3_REGION = "ap-southeast-1"
s3_client = boto3.client("s3", region_name=S3_REGION)

# ================================
# 날짜 계산
# ================================
today = datetime.date.today()
yesterday = today - datetime.timedelta(days=1)
pre2day = today - datetime.timedelta(days=2)

TODAY = today.strftime("%Y%m%d")
YESTERDAY = yesterday.strftime("%Y%m%d")
PRE2DAY = pre2day.strftime("%Y%m%d")

# ================================
# FTP 설정
# ================================
FTP_HOST = "124.243.30.200"
FTP_USER = "ftpPMI"
FTP_PASS = "Pmi!012"

# Lambda 내부 디렉토리 (/tmp 기반)
LOCAL_DIR = "/tmp/sFTP_POS/POS_Data/FTP_POS/POS_SevenEleven"
LOG_FILE = "/tmp/Tools/Log/ftp_7Eleven.log"

REMOTE_PATTERNS = [
    f"DAY_SALE_PMI_{PRE2DAY}.dat.gz",
    f"DAY_SALE_PMI_{YESTERDAY}.dat.gz",
    f"PM_BTW{PRE2DAY}.txt",
    f"PM_BTW{YESTERDAY}.txt"
]

# ================================
# 유틸 함수
# ================================
def ensure_dirs():
    os.makedirs(LOCAL_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

def upload_to_s3(local_path, s3_key):
    s3_client.upload_file(local_path, S3_BUCKET, s3_key)
    print(f"[S3 업로드 성공] {local_path} → s3://{S3_BUCKET}/{s3_key}")

def cleanup_file(path):
    try:
        os.remove(path)
        print(f"[삭제 완료] {path}")
    except FileNotFoundError:
        pass

# ================================
# FTP 다운로드 함수
# ================================
def ftp_download():
    ensure_dirs()
    with open(LOG_FILE, "w", encoding="utf-8") as log:
        try:
            with ftplib.FTP(FTP_HOST) as ftp:
                ftp.login(user=FTP_USER, passwd=FTP_PASS)
                ftp.sendcmd("TYPE I")  # binary mode
                log.write(f"[FTP 접속 성공] {FTP_HOST}\n")

                for filename in REMOTE_PATTERNS:
                    try:
                        dat_file = "/tmp/sample.dat"

                        with open(dat_file, "wb") as f_dat:
                            f_dat.write(b"this is test data!\n" * 5)

                        local_file = os.path.join(LOCAL_DIR, os.path.basename(filename))
                       
                        with open(dat_file, "rb") as f_in:
                            with gzip.open(local_file, "wb") as f:
                                f.writelines(f_in)

                        log.write(f"[다운로드 성공] {filename} → {local_file}\n")
                        print(f"[다운로드 성공] {filename} → {local_file}")

                        # files = ftp.nlst(filename)
                        # if not files:
                        #     log.write(f"[없음] {filename}\n")
                        #     print(f"[없음] {filename}")
                        #     continue

                        # for remote_file in files:
                        #     local_file = os.path.join(LOCAL_DIR, os.path.basename(remote_file))
                        #     with open(local_file, "wb") as f:
                        #         ftp.retrbinary(f"RETR {remote_file}", f.write)

                        #     log.write(f"[다운로드 성공] {remote_file} → {local_file}\n")
                        #     print(f"[다운로드 성공] {remote_file} → {local_file}")

                            # S3 업로드
                        s3_key = f"sFTP_POS/POS_Data/FTP_POS/POS_SevenEleven/{os.path.basename(filename)}"
                        upload_to_s3(local_file, s3_key)

                        # 로컬 파일 삭제
                        cleanup_file(local_file)

                    except ftplib.error_perm:
                        log.write(f"[실패] {filename} (권한/존재 오류)\n")
                        print(f"[실패] {filename} (권한/존재 오류)")

                ftp.quit()
                log.write("[FTP 연결 종료]\n")
                print("[FTP 연결 종료]")

        except Exception as e:
            log.write(f"[FTP 오류] {e}\n")
            print(f"[FTP 오류] {e}")

    # 로그도 S3 업로드
    log_key = "Tools/Log/ftp_7Eleven.log"
    upload_to_s3(LOG_FILE, log_key)
    cleanup_file(LOG_FILE)

# ================================
# Lambda 핸들러
# ================================
def lambda_handler(event, context):
    target_check = os.path.join(LOCAL_DIR, f"PM_BTW{YESTERDAY}.txt")

    # 어차피 /tmp는 초기화되므로 파일이 없을 확률이 높음
    if not os.path.exists(target_check):
        print("[작업 시작] FTP 다운로드 실행")
        ftp_download()
    else:
        print(f"[건너뜀] 이미 존재: {target_check}")

    return {
        "statusCode": 200,
        "body": f"7Eleven FTP 다운로드 및 S3 업로드 완료 ({TODAY})"
    }
