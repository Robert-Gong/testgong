"""
WithMe SFTP 다운로드 (Lambda용)
 - paramiko 사용
 - Lambda /tmp 경로 사용
 - 다운로드 후 S3 업로드
 - 로그도 S3 업로드
"""

import os
from datetime import datetime, timedelta
import paramiko
import boto3

# -----------------------------
# 날짜 계산
# -----------------------------
today = datetime.today()
yesterday = today - timedelta(days=1)

TODAY = today.strftime("%Y%m%d")
YESTERDAY = yesterday.strftime("%Y%m%d")

# -----------------------------
# 환경 설정
# -----------------------------
SFTP_HOST = "202.3.31.83"
SFTP_PORT = 1500
SFTP_USER = "pmuser"
SFTP_PASS = "PMI@emart24#"
REMOTE_DIR = "PMI"

# Lambda 전용 경로
BASE_DIR = "/tmp/sFTP_POS/POS_Data/FTP_POS/POS_WithMe"
LOG_DIR = "/tmp/Tools/Log"
LOG_WITHME = os.path.join(LOG_DIR, "ftp_WithMe.log")
LOG_TAX = os.path.join(LOG_DIR, "ftp_WithMeTAX.log")

os.makedirs(BASE_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

WITHME_FILES = [
    f"PM_WITHME{YESTERDAY}.txt",
    f"PM_WITHME_PUR{YESTERDAY}.txt",
    f"PM_WITHME{TODAY}.txt",
]
TAX_FILES = [
    f"PM_WITHME_PUR{YESTERDAY}.txt",
]

# S3 설정
S3_BUCKET = "kihub-transfer-bucket-dev"
S3_PREFIX = "sFTP_POS/POS_Data/FTP_POS/POS_WithMe/"
S3_PREFIX_LOG = "Tools/Log/"
s3_client = boto3.client("s3", region_name="ap-southeast-1")

# -----------------------------
# 로깅 및 S3 업로드
# -----------------------------
def log_write(path: str, msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}\n"
    print(line, end="")
    with open(path, "a", encoding="utf-8") as f:
        f.write(line)

def upload_to_s3(local_path: str, s3_key: str):
    try:
        s3_client.upload_file(local_path, S3_BUCKET, s3_key)
        log_write(local_path, f"[S3 UPLOAD] {local_path} → s3://{S3_BUCKET}/{s3_key}")
        os.remove(local_path)
    except Exception as e:
        log_write(local_path, f"[S3 FAIL] {local_path} → {s3_key} ({e})")

# -----------------------------
# SFTP 연결/다운로드
# -----------------------------
def open_sftp():
    transport = paramiko.Transport((SFTP_HOST, SFTP_PORT))
    transport.connect(username=SFTP_USER, password=SFTP_PASS)
    sftp = paramiko.SFTPClient.from_transport(transport)
    if REMOTE_DIR:
        sftp.chdir(REMOTE_DIR)
    return transport, sftp

def remote_exists(sftp: paramiko.SFTPClient, remote_name: str) -> bool:
    try:
        sftp.stat(remote_name)
        return True
    except FileNotFoundError:
        return False
    except IOError:
        return False

def download_set(files: list[str], log_path: str) -> None:
    try:
        # transport, sftp = open_sftp()
        log_write(log_path, f"SFTP 접속 성공: {SFTP_HOST}:{SFTP_PORT} (디렉터리: {REMOTE_DIR})")

        for name in files:
            local_path = os.path.join(BASE_DIR, name)

            if os.path.exists(local_path):
                log_write(log_path, f"[SKIP] 이미 존재: {local_path}")
                continue

            # if not remote_exists(sftp, name):
            #     log_write(log_path, f"[MISS] 원격에 없음: {name}")
            #     continue

            try:
                # sftp.get(name, local_path)
                with open(local_path, "wb") as f:
                    f.write(b"this is test file!\n" * 5)
                
                log_write(log_path, f"[OK] 다운로드 성공: {name} -> {local_path}")

                s3_key = f"{S3_PREFIX}{name}"
                upload_to_s3(local_path, s3_key)

            except Exception as e:
                if os.path.exists(local_path):
                    os.remove(local_path)
                log_write(log_path, f"[FAIL] 다운로드 실패: {name} ({e})")

        # sftp.close()
        # transport.close()
        log_write(log_path, "SFTP 연결 종료")

    except Exception as e:
        log_write(log_path, f"[ERROR] SFTP 연결 실패: {e}")

# -----------------------------
# Lambda 핸들러
# -----------------------------
def lambda_handler(event, context):
    target_withme_y = os.path.join(BASE_DIR, f"PM_WITHME{YESTERDAY}.txt")
    target_pur_y = os.path.join(BASE_DIR, f"PM_WITHME_PUR{YESTERDAY}.txt")

    if not os.path.exists(target_withme_y):
        log_write(LOG_WITHME, f"[TRIGGER] 누락 감지 -> WITHME 세트 다운로드 시작")
        download_set(WITHME_FILES, LOG_WITHME)
    else:
        log_write(LOG_WITHME, f"[SKIP] 이미 존재: {target_withme_y}")

    if not os.path.exists(target_pur_y):
        log_write(LOG_TAX, f"[TRIGGER] 누락 감지 -> TAX 세트 다운로드 시작")
        download_set(TAX_FILES, LOG_TAX)
    else:
        log_write(LOG_TAX, f"[SKIP] 이미 존재: {target_pur_y}")

    # 로그 S3 업로드
    upload_to_s3(LOG_WITHME, f"{S3_PREFIX_LOG}ftp_WithMe.log")
    upload_to_s3(LOG_TAX, f"{S3_PREFIX_LOG}ftp_WithMeTAX.log")

    return {"status": "success"}
