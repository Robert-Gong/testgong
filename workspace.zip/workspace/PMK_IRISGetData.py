import os
import logging
import boto3
import pyodbc
import pandas as pd
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
import xml.dom.minidom as minidom
from pyDes import des, PAD_PKCS5, CBC # C#의 DES 암호화 대체

# ================================
# 설정 정보 (하드코딩)
# ⚠️ 경고: 테스트용으로만 사용하세요.
# ================================
DB_HOST = "211.50.136.35"
DB_PORT = "9433"
DB_NAME = "corner_shop"
DB_USER = "sa"
DB_PASSWORD = "qwer!234"

S3_BUCKET_NAME = "kihub-transfer-bucket-dev"
S3_REGION = "ap-southeast-1"
DATA_FILE_PATH = "PMKIRIS_Data"

# ================================
# 암호화 키 (C# 소스의 key 배열과 동일)
# ==================================
KEY = b"\x6b\x6c\x6d\x6e\x6e\x6d\x6c\x6b"

# ================================
# CloudWatch Logs 설정
# ================================
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# ================================
# Boto3 S3 및 DB 클라이언트 설정
# ================================
s3_client = boto3.client('s3', region_name=S3_REGION)

# ================================
# 테이블 목록
# ================================
TABLES_DICT = {
    "categories": "M", "characters": "M", "common_d": "M", "coupons": "D",
    "discounts": "M", "order_products": "D", "orders": "D", "product_categories": "M",
    "products": "M", "shop_branches": "M", "shop_groups": "M", "shops": "M",
    "visitor_characters": "D", "consumed_coupons": "D", "callcard_ans_grp_d": "M",
    "callcard_ans_grp_h": "M", "callcard_ans_tp": "M", "callcard_answers": "D",
    "callcard_apply_shop": "M", "callcard_mst_d": "M", "callcard_mst_h": "M",
    "order_coupon": "D", "consumer": "D", "timestamps_fcm": "M", "timestamps": "D",
    "characters_q": "M", "characters_a": "M", "visitor_characters_new": "D",
    "visitors": "D", "performances": "D", "hashtag": "M", "hashtag_product": "M",
    "shop_branch_sf": "M"
}

# ================================
# C#의 ToEncryptFile() 함수를 Python으로 변환
# ================================
def encrypt_data(data):
    """
    C#의 DESCryptoServiceProvider 암호화 로직을 Python으로 구현.
    """
    try:
        cipher = des(KEY, CBC, KEY, pad=None, padmode=PAD_PKCS5)
        encrypted_data = cipher.encrypt(data.encode('utf-8'))
        return encrypted_data
    except Exception as e:
        logger.error(f"데이터 암호화 중 오류 발생: {e}")
        raise e

# ================================
# DataFrame을 XML로 변환
# ================================
def df_to_xml_string(df, root_tag, row_tag):
    """
    Pandas DataFrame을 XML 문자열로 변환합니다.
    """
    root = ET.Element(root_tag)
    for _, row in df.iterrows():
        row_element = ET.SubElement(root, row_tag)
        for col, value in row.items():
            col_element = ET.SubElement(row_element, col)
            col_element.text = str(value)
    
    xml_string = ET.tostring(root, encoding='utf-8')
    
    # 예쁘게 정렬 (pretty-print)
    dom = minidom.parseString(xml_string)
    pretty_xml_string = dom.toprettyxml(indent="  ")
    
    # minidom이 추가하는 불필요한 공백/줄바꿈 제거
    return "\n".join([line for line in pretty_xml_string.split('\n') if line.strip()])

# ================================
# 파일 저장 (S3)
# ================================
def save_file_to_s3(df, table_name, dateF, dateT, encrypt_flag=True):
    """
    데이터프레임을 XML 파일로 변환하여 S3에 저장합니다.
    """
    try:
        # Schema XML 파일 생성 및 저장
        schema_file_name = f"PMKIRIS#{table_name}#{dateF}#{dateT}#schema.xml"
        schema_s3_key = f"{DATA_FILE_PATH}/{schema_file_name}"
        
        # 스키마 정보 (컬럼 이름만 담은 단순 XML)
        schema_root = ET.Element("Schema")
        for col in df.columns:
            ET.SubElement(schema_root, "Column").set("Name", col)
        
        schema_xml_string = ET.tostring(schema_root, encoding='utf-8').decode('utf-8')
        
        if encrypt_flag:
            schema_xml_string = encrypt_data(schema_xml_string)
        
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=schema_s3_key,
            Body=schema_xml_string
        )

        # Data XML 파일 생성 및 저장
        data_file_name = f"PMKIRIS#{table_name}#{dateF}#{dateT}#data.xml"
        data_s3_key = f"{DATA_FILE_PATH}/{data_file_name}"

        data_xml_string = df_to_xml_string(df, "root", "row")
        
        if encrypt_flag:
            data_xml_string = encrypt_data(data_xml_string)
            
        s3_client.put_object(
            Bucket=S3_BUCKET_NAME,
            Key=data_s3_key,
            Body=data_xml_string
        )

        logger.info(f"[IRIS], [{dateF}] [{table_name}] XML 파일 저장 성공")

    except Exception as e:
        logger.error(f"[IRIS ERROR] save_file_to_s3() - [{table_name}] #############################")
        logger.error(e)
        raise e

# ================================
# AUTOGET 로직 (주요 변환 부분)
# ================================
def autoget():
    """
    C#의 AUTOGET() 메서드를 Python으로 변환한 함수.
    DB에서 데이터를 가져와 S3에 XML로 저장합니다.
    """
    logger.info("[IRIS START] AUTOGET() ###############################################")
    
    conn = None
    try:
        # MSSQL 연결 문자열 생성
        conn_str = (
            f'DRIVER={{ODBC Driver 17 for SQL Server}};'
            f'SERVER={DB_HOST},{DB_PORT};'
            f'DATABASE={DB_NAME};'
            f'UID={DB_USER};'
            f'PWD={DB_PASSWORD};'
        )
        conn = pyodbc.connect(conn_str)
        
        today_date_str = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")
        
        for table_name, table_type in TABLES_DICT.items():
            try:
                sql_query = ""
                # M(Master) 테이블은 전체 데이터 가져오기
                if table_type == "M":
                    sql_query = f"SELECT * FROM iris.{table_name}"
                # D(Daily) 테이블은 'updated_at' 또는 'created_at'으로 필터링
                else:
                    sql_query = (
                        f"SELECT * FROM iris.{table_name} "
                        f"WHERE (CONVERT(VARCHAR(8), updated_at, 112) = '{today_date_str}') "
                        f"OR (CONVERT(VARCHAR(8), created_at, 112) = '{today_date_str}')"
                    )
                
                logger.info(f"[{table_name}] 쿼리 실행: {sql_query}")
                
                df = pd.read_sql(sql_query, conn)
                
                if not df.empty:
                    save_file_to_s3(df, table_name, today_date_str, today_date_str, encrypt_flag=True)
                else:
                    logger.info(f"[{table_name}] 테이블에 저장할 데이터가 없습니다.")

            except Exception as ex:
                logger.error(f"[IRIS ERROR] AUTOGET() - [{table_name}] ######################################")
                logger.error(ex)

    except Exception as e:
        logger.error("[IRIS ERROR] AUTOGET() ###############################################")
        logger.error(e)
        
    finally:
        if conn:
            conn.close()
    
    logger.info("[IRIS END] AUTOGET() ###############################################")

# ================================
# 메인 Lambda 핸들러
# ================================
def lambda_handler(event, context):
    autoget()
    
    return {
        'statusCode': 200,
        'body': 'AUTOGET operation completed successfully.'
    }