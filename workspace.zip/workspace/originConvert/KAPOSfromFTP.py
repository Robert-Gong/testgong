import ftplib
import shutil
import glob
import os
import datetime

# ======================================
# Ver 22.01.01 Python 변환 (cu.in 없이 직접 FTP 접속)
#   - FTP 다운로드 (ftplib)
#   - 파일 복사 / 이동
#   - 오래된 파일 삭제
# ======================================

# ================================
# 경로 설정
# ================================
TOOLS_DIR = r"D:\Tools"
POS_DATA_DIR = r"E:\sFTP_POS\POS_Data"
LOG_DIR = os.path.join(TOOLS_DIR, "Log")

# ================================
# FTP 다운로드 함수
# ================================
def ftp_download(host, user, password, remote_patterns, local_dir):
    """
    FTP 서버에서 파일 패턴(remote_patterns)에 맞는 파일을 local_dir로 다운로드
    """
    os.makedirs(local_dir, exist_ok=True)

    try:
        with ftplib.FTP(host) as ftp:
            ftp.login(user=user, passwd=password)
            print(f"[FTP 접속 성공] {host}")

            ftp.sendcmd("TYPE I")  # 바이너리 모드

            for pattern in remote_patterns:
                try:
                    filenames = ftp.nlst(pattern)
                except ftplib.error_perm:
                    filenames = []
                    print(f"[FTP] {pattern} 파일 없음")

                for filename in filenames:
                    local_file = os.path.join(local_dir, os.path.basename(filename))
                    with open(local_file, "wb") as f:
                        ftp.retrbinary(f"RETR {filename}", f.write)
                    print(f"[다운로드 성공] {filename} → {local_file}")

            ftp.quit()
            print(f"[FTP 연결 종료] {host}")

    except Exception as e:
        print(f"[FTP 오류] {host} : {e}")


# ================================
# 파일 복사 함수
# ================================
def copy_files(pattern, source_dir, target_dir):
    for file_path in glob.glob(os.path.join(source_dir, pattern)):
        try:
            shutil.copy2(file_path, target_dir)
            print(f"[복사 성공] {file_path} → {target_dir}")
        except Exception as e:
            print(f"[복사 실패] {file_path} : {e}")


# ================================
# 파일 이동 함수
# ================================
def move_files(pattern, source_dir, target_dir):
    for file_path in glob.glob(os.path.join(source_dir, pattern)):
        try:
            shutil.move(file_path, target_dir)
            print(f"[이동 성공] {file_path} → {target_dir}")
        except Exception as e:
            print(f"[이동 실패] {file_path} : {e}")


# ================================
# 오래된 파일 삭제
# ================================
def delete_old_files(folder, days):
    cutoff = datetime.datetime.now() - datetime.timedelta(days=days)
    for file_name in os.listdir(folder):
        file_path = os.path.join(folder, file_name)
        if os.path.isfile(file_path):
            mtime = datetime.datetime.fromtimestamp(os.path.getmtime(file_path))
            if mtime < cutoff:
                try:
                    os.remove(file_path)
                    print(f"[삭제 성공] {file_path}")
                except Exception as e:
                    print(f"[삭제 실패] {file_path} : {e}")


# ================================
# 메인 실행
# ================================
def main():
    # ================================
    # CU FTP 다운로드 (cu.in 없이 직접)
    # ================================
    print("===== CU FTP 다운로드 =====")
    ftp_download(
        host="121.140.152.136",
        user="pmk",
        password="PMK",
        remote_patterns=[
            "FM_2025*.TXT",
            "PM_CU_TAX_2025*.txt",
            "PM_CU_INVENTORY_2025*.TXT"
        ],
        local_dir=os.path.join(POS_DATA_DIR, "FTP_POS", "POS_CU")
    )

    # ================================
    # GS25 파일 복사 및 이동
    # ================================
    print("===== GS25 =====")
    copy_files("PMI_D20*.gz", os.path.join(POS_DATA_DIR, "POS_GS25"),
               os.path.join(POS_DATA_DIR, "FTP_POS", "POS_GS25"))
    copy_files("PM_GS_TAX_2*.gz", os.path.join(POS_DATA_DIR, "POS_GS25"),
               os.path.join(POS_DATA_DIR, "FTP_POS", "POS_GS25"))
    copy_files("PM_GS_INVENTORY_2*.gz", os.path.join(POS_DATA_DIR, "POS_GS25"),
               os.path.join(POS_DATA_DIR, "FTP_POS", "POS_GS25"))

    move_files("PMI_D20*.gz", os.path.join(POS_DATA_DIR, "POS_GS25"),
               os.path.join(POS_DATA_DIR, "POS_OTHERS"))
    move_files("PM_GS_TAX_2*.gz", os.path.join(POS_DATA_DIR, "POS_GS25"),
               os.path.join(POS_DATA_DIR, "POS_OTHERS"))
    move_files("PM_GS_INVENTORY_2*.gz", os.path.join(POS_DATA_DIR, "POS_GS25"),
               os.path.join(POS_DATA_DIR, "POS_OTHERS"))

    # ================================
    # POK 파일 이동 및 오래된 파일 삭제
    # ================================
    print("===== POK =====")
    move_files("PM_POK_2*.txt", os.path.join(POS_DATA_DIR, "POS_POK"),
               os.path.join(POS_DATA_DIR, "POS_EMart"))
    delete_old_files(os.path.join(POS_DATA_DIR, "POS_POK"), 14)

    # ================================
    # E-Commerce 파일 이동
    # ================================
    print("===== E-Eommerce SRQ04208833 =====")
    move_files("ecomdata.csv", os.path.join(POS_DATA_DIR, "ECOM_Data", "Upload"),
               os.path.join(POS_DATA_DIR, "POS_OTHERS"))

    # ================================
    # 3PECOM 파일 백업 및 이동
    # ================================
    print("===== 3PECOM =====")
    copy_files("3rdpartyecom*.csv", os.path.join(POS_DATA_DIR, "3PECOM_Data", "3PEcomsales"),
               r"D:\Tools\Backup\3PECOM")
    move_files("3rdpartyecom*.csv", os.path.join(POS_DATA_DIR, "3PECOM_Data", "3PEcomsales"),
               os.path.join(POS_DATA_DIR, "POS_OTHERS", "3rdpartyecom.csv"))

    print("\n모든 작업 완료!")


if __name__ == "__main__":
    main()
    # 윈도우 더블클릭 시 콘솔 자동 종료 방지
    #input("아무 키나 누르면 종료됩니다...")
