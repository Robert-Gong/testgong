"""
Ministop FTPS 다운로드 (순수 Python, .scp / ftps.exe 미사용)
 - 로컬 파일 체크: DAILYMINISTOP{YESTERDAY}.txt 가 없을 경우에만 다운로드 시도
 - 날짜: today, yesterday 자동 계산
 - FTPS (FTP over TLS) 사용 (ftplib.FTP_TLS)
 - 로그: D:\Tools\Log\ftp_Ministop.log
"""

import os
import ftplib
from ftplib import FTP_TLS, error_perm, all_errors
from datetime import datetime, timedelta

# -----------------------------
# 설정
# -----------------------------
HOST = "218.234.59.18"
PORT = 995               # 원본 배치에서 995 사용; 서버 설정에 따라 21/990 등으로 변경 필요
USERNAME = "philipmorris"
PASSWORD = "philipmorris"

LOCAL_DIR = r"E:\sFTP_POS\POS_Data\FTP_POS\POS_MiniStop"
LOG_FILE = r"D:\Tools\Log\ftp_Ministop.log"

os.makedirs(LOCAL_DIR, exist_ok=True)
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

# -----------------------------
# 날짜 계산
# -----------------------------
today = datetime.today()
yesterday = today - timedelta(days=1)

TODAY = today.strftime("%Y%m%d")
YESTERDAY = yesterday.strftime("%Y%m%d")

FILES_TO_GET = [
    f"DAILYMINISTOP{YESTERDAY}.txt",
    f"DAILYMINISTOP{TODAY}.txt",
]

# -----------------------------
# 로깅 유틸
# -----------------------------
def log(msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line + "\n")


# -----------------------------
# 원격에 파일 존재하는지 확인 (패턴이 아닌 정확한 파일명)
# - FTP 서버에서 파일명이 정확히 일치하는지 stat 또는 nlst로 검사
# -----------------------------
def remote_exists(ftp: FTP_TLS, filename: str) -> bool:
    try:
        # size 또는 stat 호출로 존재여부 확인 시도
        ftp.size(filename)
        return True
    except error_perm as e:
        # 550 등의 에러면 없음
        return False
    except Exception:
        # 일부 서버는 size 미지원 -> nlst로 확인 (예외 처리)
        try:
            lst = ftp.nlst(filename)
            return len(lst) > 0
        except Exception:
            return False


# -----------------------------
# FTPS로 다운로드 수행
# -----------------------------
def download_files():
    # 먼저 로컬에 YESTERDAY 파일이 있으면 배치처럼 건너뜀
    target_yesterday_local = os.path.join(LOCAL_DIR, FILES_TO_GET[0])
    if os.path.exists(target_yesterday_local):
        log(f"[SKIP] 이미 존재: {target_yesterday_local}  -> 다운로드 불필요")
        return

    # 연결 시도
    try:
        log(f"FTPS 접속 시도: {HOST}:{PORT} (user={USERNAME})")
        ftps = FTP_TLS()
        ftps.connect(HOST, PORT, timeout=30)   # 포트 및 타임아웃 조정 가능
        ftps.login(USERNAME, PASSWORD)
        # Explicit TLS: 암호화 채널 설정. 일부 서버는 implicit FTPS(포트 990/995) 필요하므로 실패 시 포트 변경을 시도하세요.
        try:
            ftps.prot_p()  # 보호된 데이터 채널 설정 (암호화)
        except Exception:
            # prot_p 실패해도 계속 진행해볼 수 있음 (서버에 따라 필요/불필요)
            log("prot_p() 호출 실패(암호화 데이터 채널 설정). 계속 진행 시도.")

        ftps.set_pasv(True)  # passive 모드 (scp에 passive 지시 있어 활성화)

        # 파일별 처리
        for name in FILES_TO_GET:
            local_path = os.path.join(LOCAL_DIR, name)

            # 로컬에 이미 있으면 스킵(이중 방어)
            if os.path.exists(local_path):
                log(f"[SKIP] 로컬에 이미 존재: {local_path}")
                continue

            # 원격에 파일 있는지 확인
            if not remote_exists(ftps, name):
                log(f"[MISS] 원격에 없음: {name}")
                continue

            # 다운로드
            try:
                with open(local_path, "wb") as f:
                    log(f"[DOWN] {name} -> {local_path} 시작")
                    ftps.retrbinary(f"RETR {name}", f.write)
                log(f"[OK] 다운로드 완료: {local_path}")
            except all_errors as e:
                # 실패 시 있던 파일은 삭제(부분 파일 방지)
                if os.path.exists(local_path):
                    try:
                        os.remove(local_path)
                    except Exception:
                        pass
                log(f"[FAIL] 다운로드 실패: {name} ({e})")

        # 연결 종료
        try:
            ftps.quit()
        except Exception:
            try:
                ftps.close()
            except Exception:
                pass
        log("FTPS 연결 종료")

    except Exception as e:
        log(f"[ERROR] FTPS 연결/작업 중 오류: {e}")


# -----------------------------
# 메인 흐름
# -----------------------------
def main():
    log(f"TODAY={TODAY}  YESTERDAY={YESTERDAY}")
    download_files()
    log("작업 종료")


if __name__ == "__main__":
    main()
    input("\n작업 완료! 아무 키나 누르면 종료됩니다...")
