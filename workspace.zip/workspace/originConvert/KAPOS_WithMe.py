"""
WithMe SFTP 다운로드 (배치 -> 파이썬 변환)
 - .scp 파일/외부 exe 사용 안 함
 - 어제/오늘 날짜 계산
 - 로컬 파일 존재 여부 확인 후 필요 시에만 SFTP 접속/다운로드
 - 원본 배치의 분기 로직(goftp/goftpTAX) 재현
"""

import os
from datetime import datetime, timedelta

import paramiko  # pip install paramiko

# ===============================
# 날짜 계산
# ===============================
today = datetime.today()
yesterday = today - timedelta(days=1)

TODAY = today.strftime("%Y%m%d")
YESTERDAY = yesterday.strftime("%Y%m%d")

print(f"TODAY     : {TODAY}")
print(f"YESTERDAY : {YESTERDAY}")
print()

# ===============================
# 환경 설정
# ===============================
SFTP_HOST = "202.3.31.83"
SFTP_PORT = 1500
SFTP_USER = "pmuser"
SFTP_PASS = "PMI@emart24#"
REMOTE_DIR = "PMI"  # 배치의 `cd PMI`에 해당

LOCAL_DIR = r"E:\sFTP_POS\POS_Data\FTP_POS\POS_WithMe"
LOG_DIR = r"D:\Tools\Log"
LOG_WITHME = os.path.join(LOG_DIR, "ftp_WithMe.log")
LOG_TAX = os.path.join(LOG_DIR, "ftp_WithMeTAX.log")

os.makedirs(LOCAL_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

# 배치에서 만들던 파일 세트
WITHME_FILES = [
    f"PM_WITHME{YESTERDAY}.txt",
    f"PM_WITHME_PUR{YESTERDAY}.txt",
    f"PM_WITHME{TODAY}.txt",
]
TAX_FILES = [
    f"PM_WITHME_PUR{YESTERDAY}.txt",
]


# ===============================
# 유틸: 로깅
# ===============================
def log_write(path: str, msg: str) -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}\n"
    print(line, end="")
    with open(path, "a", encoding="utf-8") as f:
        f.write(line)


# ===============================
# SFTP 연결/다운로드
# ===============================
def open_sftp():
    """SFTP 접속을 열고 작업 디렉터리로 이동한 sftp 클라이언트를 반환"""
    transport = paramiko.Transport((SFTP_HOST, SFTP_PORT))
    transport.connect(username=SFTP_USER, password=SFTP_PASS)
    sftp = paramiko.SFTPClient.from_transport(transport)
    if REMOTE_DIR:
        sftp.chdir(REMOTE_DIR)
    return transport, sftp


def remote_exists(sftp: paramiko.SFTPClient, remote_name: str) -> bool:
    """원격 파일 존재 여부"""
    try:
        sftp.stat(remote_name)
        return True
    except FileNotFoundError:
        return False
    except IOError:
        # 일부 서버는 권한 문제 시 다른 오류를 줄 수 있음
        return False


def download_set(files: list[str], log_path: str) -> None:
    """파일 목록을 다운로드. 로컬에 있으면 건너뜀, 원격에 없으면 로그만 남김."""
    try:
        transport, sftp = open_sftp()
        log_write(log_path, f"SFTP 접속 성공: {SFTP_HOST}:{SFTP_PORT} (디렉터리: {REMOTE_DIR})")

        for name in files:
            local_path = os.path.join(LOCAL_DIR, name)

            # 로컬에 이미 있으면 스킵 (원본 배치 분기 + 추가 방어)
            if os.path.exists(local_path):
                log_write(log_path, f"[SKIP] 이미 존재: {local_path}")
                continue

            # 원격 존재 확인
            if not remote_exists(sftp, name):
                log_write(log_path, f"[MISS] 원격에 없음: {name}")
                continue

            # 다운로드
            try:
                sftp.get(name, local_path)
                log_write(log_path, f"[OK] 다운로드 성공: {name} -> {local_path}")
            except Exception as e:
                log_write(log_path, f"[FAIL] 다운로드 실패: {name} ({e})")

        sftp.close()
        transport.close()
        log_write(log_path, "SFTP 연결 종료")

    except Exception as e:
        log_write(log_path, f"[ERROR] SFTP 연결 실패: {e}")


# ===============================
# 메인 흐름 (배치 분기 재현)
#   goftp:
#     - PM_WITHME{YESTERDAY}.txt 없으면 WITHME 세트 다운로드
#   goftpTAX:
#     - PM_WITHME_PUR{YESTERDAY}.txt 없으면 TAX 세트 다운로드
# ===============================
def main():
    target_withme_y = os.path.join(LOCAL_DIR, f"PM_WITHME{YESTERDAY}.txt")
    target_pur_y = os.path.join(LOCAL_DIR, f"PM_WITHME_PUR{YESTERDAY}.txt")

    # goftp
    if not os.path.exists(target_withme_y):
        log_write(LOG_WITHME, f"[TRIGGER] 누락 감지 -> WITHME 세트 다운로드 시작")
        download_set(WITHME_FILES, LOG_WITHME)
    else:
        log_write(LOG_WITHME, f"[SKIP] 이미 존재: {target_withme_y}")

    # goftpTAX
    if not os.path.exists(target_pur_y):
        log_write(LOG_TAX, f"[TRIGGER] 누락 감지 -> TAX 세트 다운로드 시작")
        download_set(TAX_FILES, LOG_TAX)
    else:
        log_write(LOG_TAX, f"[SKIP] 이미 존재: {target_pur_y}")

    print("\n작업 완료.")


if __name__ == "__main__":
    main()
    # 윈도우 더블클릭 시 콘솔 유지
    input("\n아무 키나 누르면 종료됩니다...")
