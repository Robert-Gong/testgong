import shutil
import glob
import os
import datetime

# ======================================
# Ver 17.01.01
# 원본 CMD 기능:
#   - 특정 패턴의 zip 파일 이동
#   - 7일 이상 지난 파일 삭제
# Python 변환 버전
# ======================================

# 기본 경로 설정
BASE_DIR = r"E:\sFTP_POS\iSMS_Data"
OUTPUT_DIR = os.path.join(BASE_DIR, "Output")

# 각 고객사별 폴더 경로
TARGET_DIRS = {
    "Young": os.path.join(BASE_DIR, "Young"),
    "SYI": os.path.join(BASE_DIR, "SYI"),
    "Hanmi": os.path.join(BASE_DIR, "Hanmi"),
}

def move_files(pattern, target_dir):
    """
    특정 패턴에 맞는 파일들을 target_dir로 이동하는 함수
    - pattern: 이동할 파일명 패턴 (예: 'iOSHH1*.zip')
    - target_dir: 이동할 대상 디렉토리 경로
    """
    # 전체 경로 패턴 생성
    search_pattern = os.path.join(OUTPUT_DIR, pattern)

    # 패턴과 일치하는 파일들을 찾음
    for file_path in glob.glob(search_pattern):
        try:
            # shutil.move 는 파일을 덮어쓰기 하지 않음 → 같은 이름이 있으면 예외 발생
            # 따라서 기존에 동일 파일이 있으면 삭제 후 이동 처리
            file_name = os.path.basename(file_path)
            dest_path = os.path.join(target_dir, file_name)

            if os.path.exists(dest_path):
                os.remove(dest_path)  # 기존 파일 삭제

            shutil.move(file_path, target_dir)
            print(f"[이동 성공] {file_name} → {target_dir}")

        except Exception as e:
            print(f"[이동 실패] {file_path} → {target_dir} : {e}")


def delete_old_files(folder, days=7):
    """
    지정된 폴더에서 특정 일수보다 오래된 파일을 삭제
    - folder: 폴더 경로
    - days: 기준 일수 (기본 7일)
    """
    cutoff = datetime.datetime.now() - datetime.timedelta(days=days)

    for file_name in os.listdir(folder):
        file_path = os.path.join(folder, file_name)

        if os.path.isfile(file_path):
            mtime = datetime.datetime.fromtimestamp(os.path.getmtime(file_path))
            if mtime < cutoff:
                try:
                    os.remove(file_path)
                    print(f"[삭제 성공] {file_path}")
                except Exception as e:
                    print(f"[삭제 실패] {file_path} : {e}")


def main():
    # ===== Young =====
    move_files("iOSHH1*.zip", TARGET_DIRS["Young"])
    move_files("iOSHH2*.zip", TARGET_DIRS["Young"])

    # ===== SamYoung (SYI) =====
    move_files("iOSHH4*.zip", TARGET_DIRS["SYI"])
    move_files("iOSHH5*.zip", TARGET_DIRS["SYI"])

    # ===== Hanmi =====
    move_files("iOSHH7*.zip", TARGET_DIRS["Hanmi"])

    # ===== SMART dat =====
    move_files("YOUNG.zip", TARGET_DIRS["Young"])
    move_files("SYI.zip", TARGET_DIRS["SYI"])
    move_files("Hanmi.zip", TARGET_DIRS["Hanmi"])

    # ===== Delete files older than 7 days =====
    delete_old_files(TARGET_DIRS["Young"], days=7)
    delete_old_files(TARGET_DIRS["SYI"], days=7)
    delete_old_files(TARGET_DIRS["Hanmi"], days=7)
    
if __name__ == "__main__":
    main()
