import os
import socket
import ftplib
import datetime
import getpass
import platform
import sys
from pathlib import Path

# -----------------------------
# 설정 (하드코딩)
# -----------------------------
CONFIG = {
    "LogPath": r"D:\Tools\POSTAXFTP\Log\\",
    "DATAFILEPATH": r"E:\sFTP_POS\POS_Data\POS_OTHERS\\"
}

# -----------------------------
# 로그 기록 함수
# -----------------------------
def write_log(msg="", ex=None):
    try:
        log_path = CONFIG["LogPath"]
        if not os.path.exists(log_path):
            os.makedirs(log_path)
        path = os.path.join(log_path, f"KAPOSDownload{datetime.datetime.now():%Y%m%d}.log")
        with open(path, "a", encoding="utf-8") as f:
            timestamp = datetime.datetime.now().strftime("[%Y%m%d %H:%M:%S] ")
            if ex:
                f.write(timestamp + "[Source   ] " + str(getattr(ex, 'source', '')) + "\n")
                f.write(timestamp + "[Message  ] " + str(ex) + "\n")
                f.write(timestamp + "[Location ] " + "".join(getattr(ex, 'stack', '')) + "\n")
            else:
                f.write(timestamp + msg + "\n")
    except Exception:
        pass

# -----------------------------
# 권한 체크 함수
# -----------------------------
def check_hostname():
    host = platform.node().upper()
    return any(h in host for h in ["PMIKRSELSQL", "PMIKRSELIIS", "PMIKRSELAPP", "PMIKRSELDEV"])

def check_userid():
    user = getpass.getuser().upper()
    allowed_users = ["HSDOH", "CSHIM", "AHAN2", "MKIM3", "SJANG9"]
    return user in allowed_users

def check_ip():
    allowed_ips = ["211.117.28.138", "211.177.31.146", "118.130.133.29"]
    try:
        host_ips = [ip[4][0] for ip in socket.getaddrinfo(socket.gethostname(), None) if ip[0] == socket.AF_INET]
        return any(ip in allowed_ips for ip in host_ips)
    except Exception:
        return False

# -----------------------------
# FTP 다운로드 클래스
# -----------------------------
class POSFTP:
    system_name = "KAPOSDownload"
    chain_name = ""

    @staticmethod
    def AUTOSAVE():
        pass  # 현재 비어있음

    @staticmethod
    def AUTOGET():
        today = datetime.datetime.now()
        strDate = (today - datetime.timedelta(days=1)).strftime("%Y%m%d")
        strDate2 = (today - datetime.timedelta(days=2)).strftime("%Y%m%d")
        write_log(f"[{POSFTP.system_name} START] ===============================================")
        POSFTP.AUTOGET_K7TAX(strDate)
        POSFTP.AUTOGET_MiniStopTAX(strDate)
        POSFTP.AUTOGET_MiniStopTAX(strDate2)
        write_log(f"[{POSFTP.system_name}   END] ===============================================")

    @staticmethod
    def AUTOGET_K7TAX(strDate):
        address = "ftp://124.243.30.200"
        username = "ftpPMI"
        password = "Pmi!012"
        filename = f"PM_K7_TAX_{strDate}.dat.gz"
        filepath = CONFIG["DATAFILEPATH"]
        POSFTP.chain_name = "K7"
        if not POSFTP.check_history(strDate, filename):
            return
        try:
            file_list = POSFTP.get_file_list(address, username, password, filename)
            if not file_list:
                write_log(f"[{POSFTP.chain_name}]  {filename} 파일 없음")
            else:
                POSFTP.download_file(address, username, password, file_list[0], filepath)
                write_log(f"[{POSFTP.chain_name}]  {filename} 파일 다운로드")
                POSFTP.write_history(strDate, filename)
        except Exception as ex:
            write_log(f"[{POSFTP.chain_name} ERROR]", ex)

    @staticmethod
    def AUTOGET_MiniStopTAX(strDate):
        address = "218.234.59.20"  # FTP 서버
        username = "philipmorris"
        password = "philipmorris"
        filename = f"PM_MS_TAX_{strDate}.txt"
        filepath = CONFIG["DATAFILEPATH"]
        POSFTP.chain_name = "Ministop"
        if not POSFTP.check_history(strDate, filename):
            return
        try:
            POSFTP.download_file(address, username, password, filename, filepath)
            write_log(f"[{POSFTP.chain_name}]  {filename} 파일 다운로드")
            POSFTP.write_history(strDate, filename)
        except Exception as ex:
            write_log(f"[{POSFTP.chain_name} ERROR]", ex)

    @staticmethod
    def download_file(address, username, password, filename, filepath):
        if not os.path.exists(filepath):
            os.makedirs(filepath)
        try:
            with ftplib.FTP_TLS(address) as ftp:
                ftp.login(username, password)
                ftp.prot_p()
                local_path = os.path.join(filepath, filename)
                with open(local_path, "wb") as f:
                    ftp.retrbinary(f"RETR {filename}", f.write)
        except Exception as ex:
            raise ex

    @staticmethod
    def get_file_list(address, username, password, filename):
        try:
            with ftplib.FTP_TLS(address) as ftp:
                ftp.login(username, password)
                ftp.prot_p()
                files = ftp.nlst()
                return [f for f in files if filename in f]
        except Exception as ex:
            raise ex

    @staticmethod
    def check_history(date_str, filename):
        path = os.path.join(CONFIG["LogPath"], f"{POSFTP.system_name}{datetime.datetime.now():%Y%m%d}.Files")
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                if filename in f.read().splitlines():
                    write_log(f"[{POSFTP.system_name}] {filename} -- 다운로드 기록 존재함")
                    return False
        return True

    @staticmethod
    def write_history(date_str, filename):
        path = os.path.join(CONFIG["LogPath"], f"{POSFTP.system_name}{datetime.datetime.now():%Y%m%d}.Files")
        with open(path, "a", encoding="utf-8") as f:
            f.write(filename + "\n")

# -----------------------------
# Main 실행
# -----------------------------
def main():
    flag = check_userid() or check_ip() or check_hostname()
    args = sys.argv[1:]
    if not args:
        if not flag:
            print("사용 권한이 없습니다")
            return
        else:
            print("GUI 모드 실행 (Python 환경에서는 미구현)")
            return

    if not flag:
        write_log("[KAPOSDownload] 사용 권한이 없습니다")
        return

    try:
        if args[0].upper() in ["AUTOGET", "AUTOSAVE"]:
            POSFTP.AUTOGET()
        else:
            write_log("[KAPOSDownload] 파라미터 오류 - AUTOGET, AUTOSAVE만 가능")
    except Exception as ex:
        write_log(ex=ex)

if __name__ == "__main__":
    main()
