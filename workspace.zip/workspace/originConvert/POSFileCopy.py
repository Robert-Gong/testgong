import os
import shutil
from datetime import datetime, timedelta
from pathlib import Path

# -----------------------------
# 하드코딩 설정
# -----------------------------
CONFIG = {
    "sourcePathCU": r"E:\sFTP_POS\POS_Data\FTP_POS\POS_CU",
    "targetPathCU": r"E:\sFTP_POS\POS_Data\POS_OTHERS",
    "sourcePath7Elelven": r"E:\sFTP_POS\POS_Data\FTP_POS\POS_SevenEleven",
    "targetPath7Elelven": r"E:\sFTP_POS\POS_Data\POS_OTHERS",
    "sourcePathMinistop": r"E:\sFTP_POS\POS_Data\FTP_POS\POS_MiniStop",
    "targetPathMinistop": r"E:\sFTP_POS\POS_Data\POS_OTHERS",
    "sourcePathGS25": r"E:\sFTP_POS\POS_Data\FTP_POS\POS_GS25",
    "targetPathGS25": r"E:\sFTP_POS\POS_Data\POS_OTHERS",
    "sourcePathWithMe": r"E:\sFTP_POS\POS_Data\FTP_POS\POS_WithMe",
    "targetPathWithMe": r"E:\sFTP_POS\POS_Data\POS_OTHERS",
    "LogPath": r"D:\Tools\Log"
}

# -----------------------------
# 로그 기록
# -----------------------------
def write_log(msg: str, ex: Exception = None):
    log_dir = Path(CONFIG["LogPath"])
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"FileCopy_{datetime.now().strftime('%Y%m')}.log"

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(f"[Time  ] {datetime.now().strftime('%Y%m%d %H:%M:%S')}\n")
        if msg:
            f.write(msg + "\n")
        if ex:
            f.write(f"[Source   ] {type(ex).__name__}\n")
            f.write(f"[Message  ] {str(ex)}\n")
        f.write("\n")

# -----------------------------
# 파일 복사
# -----------------------------
def fn_copy_files(source_path, target_path, data_files="*.*", target_date=None):
    source_path = Path(source_path)
    target_path = Path(target_path)
    target_path.mkdir(parents=True, exist_ok=True)

    if not source_path.exists():
        print(f"Source path does not exist! {source_path}")
        return

    files = list(source_path.glob(data_files))
    for file_path in files:
        try:
            if target_date and datetime.fromtimestamp(file_path.stat().st_mtime) <= target_date:
                print(f"{file_path.name} : Old Files")
                continue

            shutil.copy2(file_path, target_path / file_path.name)
            print(f"{file_path.name} : {file_path.parent}")
        except FileNotFoundError as e:
            write_log(str(e), None)
            print(str(e))
        except Exception as e:
            write_log("Error copying file", e)
            print(f"Error copying {file_path.name}: {e}")

# -----------------------------
# 메인
# -----------------------------
def main():
    print("========================")
    print("POS Files Copy Ver 1.0.0")
    print("========================")

    # 최근 15분 이내 수정된 파일만 복사
    target_date = datetime.now() - timedelta(minutes=15)

    # 경로별 파일 복사
    for key_prefix in ["CU", "7Elelven", "Ministop", "GS25", "WithMe"]:
        source_key = f"sourcePath{key_prefix}"
        target_key = f"targetPath{key_prefix}"
        source = CONFIG.get(source_key)
        target = CONFIG.get(target_key)
        if source and target:
            fn_copy_files(source, target, "*.*", target_date)

    write_log("Success Files Copy", None)
    #print("Press any key to exit.")
    #input()

if __name__ == "__main__":
    main()
