import os
import boto3
from datetime import datetime, timedelta, timezone
import glob

# ======================================
# AWS Lambda 및 S3용으로 변환 (최종 업데이트)
# ======================================

# ================================
# S3 버킷 이름 및 지역 설정
# ================================
S3_BUCKET_NAME = "kihub-transfer-bucket-dev"
S3_REGION = "ap-southeast-1"

# ================================
# Boto3 클라이언트 설정
# ================================
s3_client = boto3.client('s3', region_name=S3_REGION)

# -----------------------------
# S3 객체 이동 함수 (복사 후 원본 삭제)
# -----------------------------
def s3_move_files(source_prefix, target_prefix, pattern):
    """
    S3 특정 경로의 객체를 다른 S3 경로로 이동 (복사 후 원본 삭제)
    
    :param source_prefix: 원본 S3 경로 (예: "iSMS_Data/Output")
    :param target_prefix: 대상 S3 경로 (예: "iSMS_Data/Young")
    :param pattern: 이동할 파일명 패턴 (예: "iOSHH1*.zip")
    """
    print(f"[{datetime.now().strftime('%Y%m%d %H:%M:%S')}] '{pattern}' 패턴 파일 이동 시작")

    paginator = s3_client.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=S3_BUCKET_NAME, Prefix=source_prefix)

    for page in pages:
        if 'Contents' in page:
            for obj in page['Contents']:
                source_key = obj['Key']
                
                # S3 폴더 자체는 이동 대상에서 제외
                if source_key.endswith('/'):
                    continue

                # 패턴과 일치하는 파일만 선택
                if glob.fnmatch.fnmatch(os.path.basename(source_key), pattern):
                    target_key = os.path.join(target_prefix, os.path.basename(source_key)).replace('\\', '/')
                    
                    try:
                        # 1. 대상 경로에 동일 파일이 있는지 확인하고 삭제 (기존 shutil.move의 덮어쓰기 로직 구현)
                        #    참고: S3에서는 동일 키로 업로드/복사 시 자동으로 덮어쓰기되므로 이 부분은 단순화 가능
                        #    shutil.move는 예외를 발생시키므로, 여기서는 복사 후 삭제로 덮어쓰기 기능을 구현
                        
                        # 2. S3 객체 복사
                        s3_client.copy_object(
                            Bucket=S3_BUCKET_NAME,
                            CopySource={'Bucket': S3_BUCKET_NAME, 'Key': source_key},
                            Key=target_key
                        )
                        print(f"[이동 성공] {source_key} -> {target_key}")

                        # 3. 원본 객체 삭제
                        s3_client.delete_object(Bucket=S3_BUCKET_NAME, Key=source_key)
                        print(f"[원본 삭제 성공] {source_key}")

                    except Exception as e:
                        print(f"[이동 실패] {source_key} -> {target_key} : {e}")

# -----------------------------
# S3 오래된 파일 삭제 함수
# -----------------------------
def s3_delete_old_files(s3_prefix, days=7):
    """
    S3 특정 경로에서 지정된 일수보다 오래된 파일을 삭제
    
    :param s3_prefix: S3 폴더 경로 (예: "iSMS_Data/Young")
    :param days: 기준 일수 (기본 7일)
    """
    print(f"[{datetime.now().strftime('%Y%m%d %H:%M:%S')}] '{s3_prefix}' 경로의 7일 이상 지난 파일 삭제 시작")

    # UTC 기준으로 지정된 일수 이전의 날짜/시간 계산
    cutoff = datetime.now(timezone.utc) - timedelta(days=days)
    
    paginator = s3_client.get_paginator('list_objects_v2')
    pages = paginator.paginate(Bucket=S3_BUCKET_NAME, Prefix=s3_prefix)

    for page in pages:
        if 'Contents' in page:
            for obj in page['Contents']:
                last_modified = obj['LastModified']
                
                # 파일의 마지막 수정 시간이 기준 날짜보다 오래되었는지 확인
                if last_modified.timestamp() < cutoff.timestamp():
                    try:
                        s3_client.delete_object(Bucket=S3_BUCKET_NAME, Key=obj['Key'])
                        print(f"[삭제 성공] {obj['Key']}")
                    except Exception as e:
                        print(f"[삭제 실패] {obj['Key']} : {e}")

# -----------------------------
# 메인 Lambda 핸들러
# -----------------------------
def lambda_handler(event, context):
    print("=======================================")
    print("iSMS File Transfer & Cleanup Ver 1.0.0")
    print("=======================================")

    # S3 경로 설정 (기존 로컬 경로 구조를 S3 객체 경로로 매핑)
    S3_PATHS = {
        "OUTPUT_DIR": "iSMS_Data/Output",
        "TARGET_YOUNG": "iSMS_Data/Young",
        "TARGET_SYI": "iSMS_Data/SYI",
        "TARGET_HANMI": "iSMS_Data/Hanmi",
    }
    
    # ===== Young =====
    s3_move_files(S3_PATHS["OUTPUT_DIR"], S3_PATHS["TARGET_YOUNG"], "iOSHH1*.zip")
    s3_move_files(S3_PATHS["OUTPUT_DIR"], S3_PATHS["TARGET_YOUNG"], "iOSHH2*.zip")
    s3_move_files(S3_PATHS["OUTPUT_DIR"], S3_PATHS["TARGET_YOUNG"], "YOUNG.zip")

    # ===== SamYoung (SYI) =====
    s3_move_files(S3_PATHS["OUTPUT_DIR"], S3_PATHS["TARGET_SYI"], "iOSHH4*.zip")
    s3_move_files(S3_PATHS["OUTPUT_DIR"], S3_PATHS["TARGET_SYI"], "iOSHH5*.zip")
    s3_move_files(S3_PATHS["OUTPUT_DIR"], S3_PATHS["TARGET_SYI"], "SYI.zip")

    # ===== Hanmi =====
    s3_move_files(S3_PATHS["OUTPUT_DIR"], S3_PATHS["TARGET_HANMI"], "iOSHH7*.zip")
    s3_move_files(S3_PATHS["OUTPUT_DIR"], S3_PATHS["TARGET_HANMI"], "Hanmi.zip")

    # ===== 7일 이상 지난 파일 삭제 =====
    s3_delete_old_files(S3_PATHS["TARGET_YOUNG"], days=7)
    s3_delete_old_files(S3_PATHS["TARGET_SYI"], days=7)
    s3_delete_old_files(S3_PATHS["TARGET_HANMI"], days=7)

    print("\n모든 S3 작업이 완료되었습니다!")

    return {
        'statusCode': 200,
        'body': 'Lambda function execution complete.'
    }