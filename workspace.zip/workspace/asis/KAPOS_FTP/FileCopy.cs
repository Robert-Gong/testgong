using System;
using System.Configuration;
using System.IO;

namespace POSFileCopy;

internal class FileCopy
{
	private static void Main(string[] args)
	{
		Console.WriteLine("========================");
		Console.WriteLine("POS Files Copy Ver 1.0.0");
		Console.WriteLine("========================");
		string text = "iOSHH7504_U_20180612_192604.zip";
		string text2 = "iOSHH*.zip";
		DateTime targetDate = DateTime.Now.AddMinutes(-15.0);
		string text3 = ConfigurationManager.AppSettings["sourcePathCU"];
		string text4 = ConfigurationManager.AppSettings["targetPathCU"];
		text3 = ConfigurationManager.AppSettings["sourcePathCU"];
		text4 = ConfigurationManager.AppSettings["targetPathCU"];
		if (text3 != null)
		{
			fnCopyFiles(text3, text4, "*.*", targetDate);
		}
		text3 = ConfigurationManager.AppSettings["sourcePath7Elelven"];
		text4 = ConfigurationManager.AppSettings["targetPath7Elelven"];
		if (text3 != null)
		{
			fnCopyFiles(text3, text4, "*.*", targetDate);
		}
		text3 = ConfigurationManager.AppSettings["sourcePathMinistop"];
		text4 = ConfigurationManager.AppSettings["targetPathMinistop"];
		if (text3 != null)
		{
			fnCopyFiles(text3, text4, "*.*", targetDate);
		}
		text3 = ConfigurationManager.AppSettings["sourcePathGS25"];
		text4 = ConfigurationManager.AppSettings["targetPathGS25"];
		if (text3 != null)
		{
			fnCopyFiles(text3, text4, "*.*", targetDate);
		}
		text3 = ConfigurationManager.AppSettings["sourcePathWithMe"];
		text4 = ConfigurationManager.AppSettings["targetPathWithMe"];
		if (text3 != null)
		{
			fnCopyFiles(text3, text4, "*.*", targetDate);
		}
		WriteLog("Sucess Files Copy ", null);
		Console.WriteLine("Press any key to exit.");
	}

	private static void fnCopyFiles(string sourcePath, string targetPath, string dataFiles, DateTime targetDate)
	{
		string path = "FileCopy.txt";
		FileInfo fileInfo = null;
		string text = Path.Combine(sourcePath, path);
		string text2 = Path.Combine(targetPath, path);
		if (!Directory.Exists(targetPath))
		{
			Directory.CreateDirectory(targetPath);
		}
		if (Directory.Exists(sourcePath))
		{
			string[] files = Directory.GetFiles(sourcePath, dataFiles);
			string[] array = files;
			foreach (string text3 in array)
			{
				try
				{
					fileInfo = new FileInfo(text3);
					if (fileInfo.LastWriteTime > targetDate)
					{
						path = Path.GetFileName(text3);
						text2 = Path.Combine(targetPath, path);
						File.Copy(text3, text2, overwrite: true);
						Console.WriteLine("{0} : {1}", fileInfo.Name, fileInfo.Directory);
					}
					else
					{
						Console.WriteLine("{0} : {1}", fileInfo.Name, "Old Files");
					}
				}
				catch (FileNotFoundException ex)
				{
					WriteLog(ex.Message, null);
					Console.WriteLine(ex.Message);
				}
			}
		}
		else
		{
			Console.WriteLine("Source path does not exist!");
		}
	}

	private static void WriteLog(string msg, Exception ex)
	{
		string text = ConfigurationManager.AppSettings["LogPath"];
		if (!Directory.Exists(text))
		{
			Directory.CreateDirectory(text);
		}
		string path = text + "\\FileCopy_" + DateTime.Now.ToString("yyyyMM") + ".log";
		using StreamWriter streamWriter = new StreamWriter(path, append: true);
		streamWriter.WriteLine("[Time  ] " + DateTime.Now.ToString("yyyyMMdd HH:mm:ss"));
		if (msg != "")
		{
			streamWriter.WriteLine(msg);
		}
		if (ex != null)
		{
			streamWriter.WriteLine("[Source   ] " + ex.Source.ToString());
			streamWriter.WriteLine("[Message  ] " + ex.Message);
			streamWriter.WriteLine("[Location ] " + ex.StackTrace);
		}
		streamWriter.WriteLine();
		streamWriter.Close();
	}
}
