using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

/// <summary>
/// KAPOS 다운로드 프로그램의 네임스페이스
/// </summary>
namespace KAPOSDownload;

/// <summary>
/// KAPOS 다운로드 프로그램의 메인 폼 클래스
/// Windows Form을 상속받아 UI를 구성함
/// </summary>
public class KAPOSDown : Form
{
	/// <summary>
	/// Windows Form 디자이너에서 사용하는 컴포넌트 컨테이너
	/// </summary>
	private IContainer components = null;

	/// <summary>
	/// 자동 다운로드를 실행하는 버튼 컨트롤
	/// </summary>
	private Button btnAUTOGet;

	/// <summary>
	/// KAPOSDown 폼의 생성자
	/// 폼의 초기화 및 컴포넌트 구성을 수행함
	/// </summary>
	public KAPOSDown()
	{
		InitializeComponent();
	}

	/// <summary>
	/// 다운로드 버튼 클릭 이벤트 핸들러
	/// FTP 서버에서 자동으로 파일을 다운로드하고 완료 메시지를 표시함
	/// </summary>
	/// <param name="sender">이벤트 발생 객체</param>
	/// <param name="e">이벤트 인자</param>
	private void btnAUTOGet_Click(object sender, EventArgs e)
	{
		POSFTP.AUTOGET();
		MessageBox.Show("완료");
	}

	/// <summary>
	/// 사용된 리소스를 정리하는 메서드
	/// </summary>
	/// <param name="disposing">관리되는 리소스를 해제해야 하는지 여부</param>
	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	/// <summary>
	/// 폼 디자이너에서 사용하는 필수 메서드
	/// 모든 UI 컴포넌트의 초기화 및 속성 설정을 담당함
	/// </summary>
	private void InitializeComponent()
	{
		this.btnAUTOGet = new System.Windows.Forms.Button();
		base.SuspendLayout();
		this.btnAUTOGet.Location = new System.Drawing.Point(91, 38);
		this.btnAUTOGet.Name = "btnAUTOGet";
		this.btnAUTOGet.Size = new System.Drawing.Size(75, 23);
		this.btnAUTOGet.TabIndex = 0;
		this.btnAUTOGet.Text = "Download";
		this.btnAUTOGet.UseVisualStyleBackColor = true;
		this.btnAUTOGet.Click += new System.EventHandler(btnAUTOGet_Click);
		base.AutoScaleDimensions = new System.Drawing.SizeF(6f, 13f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(284, 261);
		base.Controls.Add(this.btnAUTOGet);
		base.Name = "KAPOSDown";
		this.Text = "KAPOSDown Ver1.0.1";
		base.ResumeLayout(false);
	}
}
