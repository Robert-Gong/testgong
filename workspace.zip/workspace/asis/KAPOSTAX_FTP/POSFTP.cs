using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using PMK.Common;

namespace KAPOSDownload;

// FTP 서버에서 POS 거래 데이터를 자동으로 다운로드하는 클래스입니다.
// K7 및 Ministop 체인에서 거래 정보를 가져오며, 이미 다운로드된 파일은 다시 다운로드하지 않습니다.
internal class POSFTP
{
	// 시스템 이름을 저장하는 정적 변수입니다. 로그 기록에 사용됩니다.
	private static string strSystemName = "KAPOSDownload";

	// 체인 이름을 저장하는 정적 변수입니다. 로그 기록에 사용됩니다.
	private static string strChainName = "";

	// 모든 FTP 파일을 자동으로 다운로드하는 메서드입니다.
	// 어제 및 그 이전 날짜의 K7 및 Ministop 파일들을 다운로드합니다.
	public static void AUTOGET()
	{
		// 어제 날짜를 yyyyMMdd 형식으로 가져옵니다.
		string strDate = DateTime.Now.AddDays(-1.0).ToString("yyyyMMdd");
		// 이틀 전 날짜를 yyyyMMdd 형식으로 가져옵니다.
		string strDate2 = DateTime.Now.AddDays(-2.0).ToString("yyyyMMdd");
		// 시작 로그를 기록합니다.
		LogFile.WriteLog("[" + strSystemName + " START] ===============================================");
		// 어제의 K7 파일을 다운로드합니다.
		AUTOGET_K7TAX(strDate);
		// 어제의 Ministop 파일을 다운로드합니다.
		AUTOGET_MiniStopTAX(strDate);
		// 이틀 전의 Ministop 파일을 다운로드합니다.
		AUTOGET_MiniStopTAX(strDate2);
		// 종료 로그를 기록합니다.
		LogFile.WriteLog("[" + strSystemName + "   END] ===============================================");
	}

	// 현재는 비어있는 메서드입니다. 나중에 구현될 수 있습니다.
	public static void AUTOSAVE()
	{
	}

	// K7 체인의 FTP 파일을 다운로드하는 메서드입니다.
	// 지정된 날짜의 K7 파일을 FTP 서버에서 다운로드합니다.
	public static void AUTOGET_K7TAX(string strDate)
	{
		// 어제 날짜를 yyyyMMdd 형식으로 가져옵니다.
		string text = DateTime.Now.AddDays(-1.0).ToString("yyyyMMdd");
		// FTP 서버 주소를 설정합니다.
		string address = "ftp://124.243.30.200";
		// FTP 사용자 이름을 설정합니다.
		string username = "ftpPMI";
		// FTP 비밀번호를 설정합니다.
		string password = "Pmi!012";
		// K7 파일의 접두사를 정의합니다.
		string text2 = "PM_K7_TAX_";
		// K7 파일의 확장자를 정의합니다.
		string text3 = ".dat.gz";
		// 완성된 K7 파일명을 생성합니다.
		string text4 = text2 + strDate + text3;
		// 데이터 파일이 저장될 경로를 가져옵니다.
		string strFilepath = ConfigurationManager.AppSettings["DATAFILEPATH"];
		// 날짜 변수를 갱신합니다.
		text = strDate;
		// 체인 이름을 K7로 설정합니다.
		strChainName = "K7";
		// 이미 다운로드된 파일인지 확인하고, 다운로드되지 않았다면 진행합니다.
		if (!checkHistory(text, text4))
		{
			return;
		}
		try
		{
			// FTP에서 파일 목록을 가져옵니다.
			List<string> fileList = getFileList(address, username, password, text4);
			// 파일 목록이 비어있으면 로그를 기록합니다.
			if (fileList.Count == 0)
			{
				LogFile.WriteLog("[" + strChainName + "]  " + text4 + " 파일 없음");
			}
			else
			{
				// 파일을 다운로드합니다.
				downloadFile(address, username, password, fileList[0], strFilepath);
				// 다운로드 성공 시 로그를 기록합니다.
				LogFile.WriteLog("[" + strChainName + "]  " + text4 + " 파일 다운로드");
				// 다운로드 히스토리를 기록합니다.
				writeHistory(text, text4);
			}
		}
		catch (Exception ex)
		{
			// 에러 발생 시 로그를 기록합니다.
			LogFile.WriteLog("[" + strChainName + " ERROR]");
			LogFile.WriteLog(ex);
		}
		finally
		{
		}
	}

	// Ministop 체인의 FTP 파일을 다운로드하는 메서드입니다.
	// 지정된 날짜의 Ministop 파일을 FTP 서�에서 다운로드합니다.
	public static void AUTOGET_MiniStopTAX(string strDate)
	{
		// 어제 날짜를 yyyyMMdd 형식으로 가져옵니다.
		string text = DateTime.Now.AddDays(-1.0).ToString("yyyyMMdd");
		// FTP 서� 주소를 설정합니다.
		string text2 = "ftp://218.234.59.18:995";
		// FTP 서� 주소를 변경합니다.
		text2 = "ftp://218.234.59.20:995";
		// FTP 사용자 이름을 설정합니다.
		string username = "philipmorris";
		// FTP 비밀번호를 설정합니다.
		string password = "philipmorris";
		// Ministop 파일의 접두사를 정의합니다.
		string text3 = "PM_MS_TAX_";
		// Ministop 파일의 확장자를 정의합니다.
		string text4 = ".txt";
		// 완성된 Ministop 파일명을 생성합니다.
		string text5 = text3+  strDate + text4;
		// 데이터 파일이 저장될 경로를 가져옵니다.
		string strFilepath = ConfigurationManager.AppSettings["DATAFILEPATH"];
		// 날짜 변수를 갱신합니다.
		text = strDate;
		// 체인 이름을 Ministop으로 설정합니다.
		strChainName = "Ministop";
		// 이미 다운로드된 파일인지 확인하고, 다운로드되지 않았다면 진행합니다.
		if (!checkHistory(text, text5))
		{
			return;
		}
		try
		{
			// FTP에서 파일 목록을 가져옵니다.
			List<string> fileList = getFileList(text2, username, password, text5);
			// 파일 목록이 비어있으면 로그를 기록합니다.
			if (fileList.Count == 0)
			{
				LogFile.WriteLog("[" + strChainName + "]  " + text5 + " 파일 없음");
			}
			else
			{
				// 파일을 다운로드합니다.
				downloadFile(text2, username, password, fileList[0], strFilepath);
				// 다운로드 성공 시 로그를 기록합니다.
				LogFile.WriteLog("[" + strChainName + "]  " + text5 + " 파일 다운로드");
				// 다운로드 히스토리를 기록합니다.
				writeHistory(text, text5);
			}
		}
		catch (Exception ex)
		{
			// 에러 발생 시 로그를 기록합니다.
			LogFile.WriteLog("[" + strChainName + " ERROR]");
			LogFile.WriteLog(ex);
		}
		finally
		{
		}
	}

	// FTP 파일을 다운로드하는 내부 메서드입니다.
	// 지정된 FTP 주소에서 파일을 다운로드합니다.
	private static void downloadFile(string address, string username, string password, string filename, string strFilepath)
	{
		// 파일 저장 경로가 존재하지 않으면 생성합니다.
		if (!Directory.Exists(strFilepath))
		{
			Directory.CreateDirectory(strFilepath);
		}
		try
		{
			// WebClient를 사용하여 파일을 다운로드합니다.
			using WebClient webClient = new WebClient();
			// FTP 인증 정보를 설정합니다.
			webClient.Credentials = new NetworkCredential(username, password);
			// 전체 FTP 주소를 만듭니다.
			string address2 = address + "/" + filename;
			// 파일 저장 경로를 만듭니다.
			string fileName = strFilepath + filename;
			// 파일을 다운로드합니다.
			webClient.DownloadFile(address2, fileName);
		}
		catch (Exception ex)
		{
			// 예외 발생 시 다시 던집니다.
			throw ex;
		}
	}

	// FTP 서�에서 파일 목록을 가져오는 내부 메서드입니다.
	// 지정된 FTP 주소에서 파일 목록을 가져와서, 특정 파일명이 포함된 항목만 반환합니다.
	private static List<string> getFileList(string address, string username, string password, string filename)
	{
		// 파일 목록 배열을 선언합니다.
		string[] source = null;
		try
		{
			// FTP 요청을 생성합니다.
			FtpWebRequest ftpWebRequest = (FtpWebRequest)WebRequest.Create(address);
			// NLST 명령을 사용하여 파일 목록을 가져옵니다.
			ftpWebRequest.Method = "NLST";
			// FTP 인증 정보를 설정합니다.
			ftpWebRequest.Credentials = new NetworkCredential(username, password);
			// Passive 모드를 사용합니다.
			ftpWebRequest.UsePassive = true;
			// Binary 모드를 사용합니다.
			ftpWebRequest.UseBinary = true;
			// KeepAlive를 비활성화합니다.
			ftpWebRequest.KeepAlive = false;
			// FTP 응답을 받습니다.
			using (FtpWebResponse ftpWebResponse = (FtpWebResponse)ftpWebRequest.GetResponse())
			{
				// 응답 스트림을 읽습니다.
				using (StreamReader streamReader = new StreamReader(ftpWebResponse.GetResponseStream()))
				{
					// 응답을 줄 단위로 분할합니다.
					source = streamReader.ReadToEnd().Split(new string[1] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
					// 스트림을 닫습니다.
					streamReader.Close();
				}
				// FTP 응답을 닫습니다.
				ftpWebResponse.Close();
			}
			// FTP 요청을 종료합니다.
			ftpWebRequest.Abort();
		}
		catch (Exception ex)
		{
			// 예외 발생 시 다시 던집니다.
			throw ex;
		}
		// 파일명에 해당하는 항목만 필터링하여 반환합니다.
		return source.Where((string f) => f.IndexOf(filename) != -1).ToList();
	}

	// 히스토리 파일을 확인하여 이미 다운로드된 파일인지 확인하는 메서드입니다.
	// 지정된 날짜와 파일명이 이미 기록되어 있는지 확인합니다.
	private static bool checkHistory(string startdate, string destfile)
	{
		// 히스토리 파일의 경로를 생성합니다.
		string path = ConfigurationManager.AppSettings["LogPath"] + strSystemName + DateTime.Now.ToString("yyyyMMdd") + ".Files";
		// 히스토리 파일이 존재하는지 확인합니다.
		if (File.Exists(path))
		{
			// 파일을 읽기 위해 스트림 리더를 생성합니다.
			using StreamReader streamReader = new StreamReader(path);
			string text = "";
			// 파일의 각 줄을 읽습니다.
			while ((text = streamReader.ReadLine()) != null)
			{
				// 같은 파일명이 존재하면 이미 다운로드된 것으로 판단하고 false를 반환합니다.
				if (text == destfile)
				{
					LogFile.WriteLog("[" + strSystemName + "] " + destfile + " -- 다운로드 기록 존재함");
					streamReader.Close();
					return false;
				}
			}
			// 스트림 리더를 닫습니다.
			streamReader.Close();
		}
		// 히스토리에 기록되지 않은 경우 true를 반환합니다.
		return true;
	}

	// 다운로드 히스토리를 기록하는 메서드입니다.
	// 다운로드된 파일명을 히스토리 파일에 추가합니다.
	private static void writeHistory(string startdate, string destfile)
	{
		// 히스토리 파일의 경로를 생성합니다.
		string path = ConfigurationManager.AppSettings["LogPath"] + strSystemName + DateTime.Now.ToString("yyyyMMdd") + ".Files";
		// 히스토리 파일에 파일명을 추가합니다.
		using StreamWriter streamWriter = new StreamWriter(path, append: true);
		streamWriter.WriteLine(destfile);
		// 스트림 웨이터를 닫습니다.
		streamWriter.Close();
	}
}
