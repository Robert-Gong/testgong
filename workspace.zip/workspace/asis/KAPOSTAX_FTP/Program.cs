using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using PMK.Common;

namespace KAPOSDownload;

// 프로그램의 메인 클래스입니다. 
// 이 클래스는 프로그램 실행 시 가장 먼저 호출되는 Main 함수를 포함하고 있습니다.
internal static class Program
{
	// 메인 함수입니다. 
	// 프로그램이 시작될 때 호출되며, 명령줄 인수에 따라 다른 동작을 합니다.
	// 인수가 없으면 GUI 모드로 실행되고, 인수가 있으면 명령줄 모드로 실행됩니다.
	[STAThread]
	private static void Main(string[] args)
	{
		// 사용자 ID, IP 주소, 컴퓨터 이름을 확인하는 함수들을 호출하여 권한 여부를 판단합니다.
		// 이 변수는 사용자가 허용된 사용자인지 확인하는 데 사용됩니다.
		bool flag = CheckUserid() || CheckIP() || CheckHostName();
		
		// 인수가 없는 경우 (GUI 모드)
		if (args.Length == 0)
		{
			// 사용자 권한이 없는 경우 경고 메시지를 표시하고 종료합니다.
			if (!flag)
			{
				MessageBox.Show("사용 권한이 없습니다", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			
			// Windows 폼 애플리케이션의 시각적 스타일을 활성화합니다.
			Application.EnableVisualStyles();
			
			// 텍스트 렌더링 기본 설정을 지정합니다.
			Application.SetCompatibleTextRenderingDefault(defaultValue: false);
			
			// KAPOSDown 폼을 생성하고 실행합니다. 
			// 이는 프로그램의 메인 GUI 창입니다.
			Application.Run(new KAPOSDown());
			return;
		}
		
		// 인수가 있는 경우 (명령줄 모드)
		if (!flag)
		{
			// 사용 권한이 없는 경우 로그 파일에 기록합니다.
			LogFile.WriteLog("[KAPOSDownload] 사용 권한이 없습니다");
			return;
		}
		
		// 예외 처리 블록입니다.
		// 실행 도중 오류가 발생하면 로그 파일에 예외 내용을 기록합니다.
		try
		{
			// 인수의 첫 번째 값이 "AUTOGET"인 경우
			if (args[0] == "AUTOGET")
			{
				// POSFTP 클래스의 AUTOGET 메서드를 호출합니다.
				// 이 메서드는 FTP 서버에서 파일을 다운로드하는 작업을 수행합니다.
				POSFTP.AUTOGET();
			}
			// 인수의 첫 번째 값이 "AUTOSAVE"인 경우
			else if (args[0] == "AUTOSAVE")
			{
				// POSFTP 클래스의 AUTOGET 메서드를 호출합니다.
				// 이 메서드는 FTP 서�에서 파일을 다운로드하는 작업을 수행합니다.
				POSFTP.AUTOGET();
			}
			// 위 두 조건에 해당하지 않으면 오류 메시지를 로그에 기록합니다.
			else
			{
				LogFile.WriteLog("[KAPOSDownload] 파라미터 오류 - AUTOGET, AUTOSAVE만 가능");
			}
		}
		// 예외가 발생하면 로그에 예외 내용을 기록합니다.
		catch (Exception ex)
		{
			LogFile.WriteLog(ex);
		}
	}

	/// <summary>
	/// 컴퓨터의 이름이 허용된 목록에 있는지 확인하는 함수
	/// 컴퓨터 이름이 PMIKRSELSQL, PMIKRSELIIS, PMIKRSELAPP, PMIKRSELDEV 중 하나와 일치하면 true를 반환
	/// </summary>
	// 컴퓨터 이름이 허용된 목록에 있는지 확인합니다.
	// 허용된 이름이면 true를 반환하고, 그렇지 않으면 false를 반환합니다.
	private static bool CheckHostName()
	{
		// 현재 컴퓨터의 이름을 대문자로 변환하여 가져옵니다.
		string text = Environment.MachineName.ToUpper();
		
		// 컴퓨터 이름이 허용된 목록에 있는지 확인합니다.
		// 허용된 이름이면 true를 반환합니다.
		return text.IndexOf("PMIKRSELSQL") != -1 || text.IndexOf("PMIKRSELIIS") != -1 || text.IndexOf("PMIKRSELAPP") != -1 || text.IndexOf("PMIKRSELDEV") != -1;
	}

	// 사용자 ID가 허용된 목록에 있는지 확인하는 함수입니다.
	// 허용된 사용자 ID면 true를 반환하고, 그렇지 않으면 false를 반환합니다.
	private static bool CheckUserid()
	{
		// 현재 사용자의 이름을 대문자로 변환하여 가져옵니다.
		string text = Environment.UserName.ToUpper();
		
		// 사용자 ID에 따라 결과값을 결정합니다.
		// 허용된 사용자 ID이면 1을 반환하고, 그렇지 않으면 0을 반환합니다.
		int result;
		switch (text)
		{
		// 허용된 사용자 ID가 아닌 경우
		default:
			result = ((text == "SJANG9") ? 1 : 0);
			break;
		// 허용된 사용자 ID인 경우
		case "HSDOH":
		case "CSHIM":
		case "AHAN2":
		case "MKIM3":
			result = 1;
			break;
		}
		
		// 결과값이 0이 아닌지 확인하여 true/false를 반환합니다.
		return (byte)result != 0;
	}

	// IP 주소가 허용된 목록에 있는지 확인하는 함수입니다.
	// 허용된 IP 주소면 true를 반환하고, 그렇지 않으면 false를 반환합니다.
	private static bool CheckIP()
	{
		// 현재 컴퓨터의 호스트 이름에 대한 IP 주소 정보를 가져옵니다.
		IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
		
		// IP 주소 목록을 순회하면서 허용된 IP 주소인지 확인합니다.
		for (int i = 0; i < hostEntry.AddressList.Length; i++)
		{
			// IP 주소가 IPv4 형식이고, 허용된 IP 주소 중 하나와 일치하면 true를 반환합니다.
			if (hostEntry.AddressList[i].AddressFamily == AddressFamily.InterNetwork && (hostEntry.AddressList[i].ToString() == "211.117.28.138" || hostEntry.AddressList[i].ToString() == "211.177.31.146" || hostEntry.AddressList[i].ToString() == "118.130.133.29"))
			{
				return true;
			}
		}
		
		// 허용된 IP 주소가 없으면 false를 반환합니다.
		return false;
	}
}
