import os
import ftplib
import datetime
import boto3

# -----------------------------
# Lambda 전용 경로 및 S3 설정
# -----------------------------
BASE_DIR = "/tmp/sFTP_POS/POS_Data/POS_OTHERS"
LOG_DIR = "/tmp/Tools/POSTAXFTP/Log"

K7TAX_HOST = "124.243.30.200"
K7TAX_PORT = 21
K7TAX_USERNAME = "ftpPMI"
K7TAX_PASSWORD = "Pmi!012"

MSTAX_HOST = "218.234.59.20"
MSTAX_PORT = 995
MSTAX_USERNAME = "philipmorris"
MSTAX_PASSWORD = "philipmorris"


os.makedirs(BASE_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

S3_BUCKET = "kihub-transfer-bucket-dev"
S3_FILE_PREFIX = "sFTP_POS/POS_Data/POS_OTHERS/"
S3_LOG_PREFIX = "Tools/POSTAXFTP/Log/"
s3_client = boto3.client("s3", region_name="ap-southeast-1")

# -----------------------------
# 날짜 계산
# -----------------------------
today = datetime.datetime.now()
YESTERDAY = (today - datetime.timedelta(days=1)).strftime("%Y%m%d")
PRE2DAY = (today - datetime.timedelta(days=2)).strftime("%Y%m%d")

# -----------------------------
# 파일 기록/로그 기록 유틸
# -----------------------------
def write_log(msg="", log_file=None, ex=None):
    if not log_file:
        log_file = os.path.join(LOG_DIR, f"KAPOSDownload{today:%Y%m%d}.log")
    ts = datetime.datetime.now().strftime("[%Y%m%d %H:%M:%S] ")
    with open(log_file, "a", encoding="utf-8") as f:
        if ex:
            f.write(ts + "[Source   ] " + str(getattr(ex, 'source', '')) + "\n")
            f.write(ts + "[Message  ] " + str(ex) + "\n")
            f.write(ts + "[Location ] " + "".join(getattr(ex, 'stack', '')) + "\n")
        else:
            f.write(ts + msg + "\n")
    print(ts + msg)
    return log_file

def upload_to_s3(local_path, s3_key):
    try:
        s3_client.upload_file(local_path, S3_BUCKET, s3_key)
        print(f"[S3 UPLOAD] {local_path} → s3://{S3_BUCKET}/{s3_key}")
        os.remove(local_path)
    except Exception as e:
        print(f"[S3 FAIL] {local_path} → {s3_key} ({e})")

# -----------------------------
# FTP 다운로드
# -----------------------------
def download_ftp(address, port, username, password, filename):
    local_path = os.path.join(BASE_DIR, filename)
    try:
        with ftplib.FTP(encoding='euc-kr') as ftp:
            ftp.connect(address, port)
            ftp.login(username, password)
   
            with open(local_path, "wb") as f:
                ftp.retrbinary(f"RETR {filename}", f.write)
        s3_key = S3_FILE_PREFIX + filename
        upload_to_s3(local_path, s3_key)
        return True
    except Exception as ex:
        write_log(f"[FAIL] {filename} 다운로드 실패", ex=ex)
        return False

# -----------------------------
# 다운로드 기록 확인
# -----------------------------
def check_history(filename):
    history_file = os.path.join(LOG_DIR, f"KAPOSDownload{today:%Y%m%d}.Files")
    if os.path.exists(history_file):
        with open(history_file, "r", encoding="utf-8") as f:
            if filename in f.read().splitlines():
                write_log(f"{filename} -- 다운로드 기록 존재함")
                return False
    return True

def write_history(filename):
    history_file = os.path.join(LOG_DIR, f"KAPOSDownload{today:%Y%m%d}.Files")
    with open(history_file, "a", encoding="utf-8") as f:
        f.write(filename + "\n")
    s3_key = S3_LOG_PREFIX + os.path.basename(history_file)
    upload_to_s3(history_file, s3_key)

# -----------------------------
# Lambda 핸들러
# -----------------------------
def lambda_handler(event, context):
    # K7 TAX 다운로드
    k7_files = [f"PM_K7_TAX_{YESTERDAY}.dat.gz"]
    for filename in k7_files:
        if check_history(filename):
            if download_ftp(K7TAX_HOST, K7TAX_PORT, K7TAX_USERNAME, K7TAX_PASSWORD, filename):
                write_log(f"[K7] {filename} 다운로드 완료")
                write_history(filename)

    # Ministop TAX 다운로드
    ms_files = [f"PM_MS_TAX_{YESTERDAY}.txt", f"PM_MS_TAX_{PRE2DAY}.txt"]
    for filename in ms_files:
        if check_history(filename):
            if download_ftp(MSTAX_HOST, MSTAX_PORT, MSTAX_USERNAME, MSTAX_PASSWORD, filename):
                write_log(f"[Ministop] {filename} 다운로드 완료")
                write_history(filename)

    s3_key = S3_LOG_PREFIX + f"KAPOSDownload{today:%Y%m%d}.log"
    upload_to_s3(write_log(f"배치 종료"), s3_key)

    return {"status": "success"}
