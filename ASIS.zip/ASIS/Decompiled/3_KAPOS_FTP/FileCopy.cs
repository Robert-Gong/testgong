using System;
using System.Configuration;
using System.IO;

//
// 실행은 아마 이렇게 될것임:
//
// ========================
// POS Files Copy Ver 1.0.0
// ========================
//
// fnCopyFiles(text_A, text_B, "*.*", targetDate)
// fnCopyFiles(text_A, text_B, "*.*", targetDate)
// fnCopyFiles(text_A, text_B, "*.*", targetDate)
// fnCopyFiles(text_A, text_B, "*.*", targetDate)
// fnCopyFiles(text_A, text_B, "*.*", targetDate)
// WriteLog("Sucess Files Copy ", null)
// Press any key to exit.
//


// POS(Point of Sale) 시스템의 파일 복사 기능을 담당하는 네임스페이스
// Java의 패키지와 동일한 개념으로, 관련 클래스들을 그룹화하는 역할을 함
namespace POSFileCopy;

// 편의점 POS 시스템의 파일을 복사하는 기능을 제공하는 클래스
// Java의 class와 동일하며, internal은 같은 프로젝트 내에서만 접근 가능함을 의미함
internal class FileCopy {

	// 프로그램의 시작점(Entry Point)으로, Java의 main 메소드와 동일한 역할
	// 각 편의점 체인별로 설정된 경로에서 파일을 복사하는 작업을 수행
	// ConfigurationManager를 통해 외부 설정 파일에서 경로 정보를 읽어옴
	private static void Main(string[] args) {

		Console.WriteLine("========================");
		Console.WriteLine("POS Files Copy Ver 1.0.0");
		Console.WriteLine("========================");
		// 테스트용 변수들 - 실제 실행 시에는 사용되지 않음
		string text = "iOSHH7504_U_20180612_192604.zip";
		string text2 = "iOSHH*.zip";
		// 현재 시간으로부터 15분 전의 날짜를 계산하여 targetDate에 저장
		DateTime targetDate = DateTime.Now.AddMinutes(-15.0);

		// CU 편의점의 원본 및 대상 경로를 설정 파일에서 읽어옴
		string text_A = ConfigurationManager.AppSettings["sourcePathCU"];
		string text_B = ConfigurationManager.AppSettings["targetPathCU"];
		// sourcePathCU가 null이 아니라면 해당 경로에서 파일들을 복사함
		if (text_A != null) {
			fnCopyFiles(text_A, text_B, "*.*", targetDate);
		}

		// 7 Eleven 편의점의 원본 및 대상 경로를 설정 파일에서 읽어옴
		text_A = ConfigurationManager.AppSettings["sourcePath7Elelven"];
		text_B = ConfigurationManager.AppSettings["targetPath7Elelven"];
		// sourcePath7Elelven가 null이 아니라면 해당 경로에서 파일들을 복사함
		if (text_A != null) {
			fnCopyFiles(text_A, text_B, "*.*", targetDate);
		}

		// 미니 스탑 편의점의 원본 및 대상 경로를 설정 파일에서 읽어옴
		text_A = ConfigurationManager.AppSettings["sourcePathMinistop"];
		text_B = ConfigurationManager.AppSettings["targetPathMinistop"];
		// sourcePathMinistop가 null이 아니라면 해당 경로에서 파일들을 복사함
		if (text_A != null) {
			fnCopyFiles(text_A, text_B, "*.*", targetDate);
		}

		// GS25 편의점의 원본 및 대상 경로를 설정 파일에서 읽어옴
		text_A = ConfigurationManager.AppSettings["sourcePathGS25"];
		text_B = ConfigurationManager.AppSettings["targetPathGS25"];
		// sourcePathGS25가 null이 아니라면 해당 경로에서 파일들을 복사함
		if (text_A != null) {
			fnCopyFiles(text_A, text_B, "*.*", targetDate);
		}

		// 웨더미 편의점의 원본 및 대상 경로를 설정 파일에서 읽어옴
		text_A = ConfigurationManager.AppSettings["sourcePathWithMe"];
		text_B = ConfigurationManager.AppSettings["targetPathWithMe"];
		// sourcePathWithMe가 null이 아니라면 해당 경로에서 파일들을 복사함
		if (text_A != null) {
			fnCopyFiles(text_A, text_B, "*.*", targetDate);
		}

		// 모든 편의점에서 파일 복사를 완료한 후 로그를 기록함
		WriteLog("Sucess Files Copy ", null);
		Console.WriteLine("Press any key to exit.");

	}

	// 지정된 소스 경로에서 대상 경로로 파일을 복사하는 메소드
	// sourcePath: 원본 파일이 있는 경로 (Java의 String과 동일)
	// targetPath: 복사될 대상 경로
	// dataFiles: 복사할 파일의 패턴 (예: *.* 는 모든 파일)       >>> 사실상 항상 모든파일을 갖고옴
	// targetDate: 이 날짜 이후에 수정된 파일만 복사함
	private static void fnCopyFiles(string sourcePath, string targetPath, string dataFiles, DateTime targetDate) {
		// 복사할 파일의 경로를 설정
		string path = "FileCopy.txt";
		// 파일 정보를 담을 FileInfo 객체 선언
		FileInfo fileInfo = null;

		// 원본 파일의 전체 경로를 생성 (sourcePath + path)
		// string file_source_one = Path.Combine(sourcePath, path);
		// 대상 파일의 전체 경로를 생성 (targetPath + path) >>>>>>>>> 안씀
		// string file_target_one = Path.Combine(targetPath, path);

		// 대상 폴더가 존재하지 않는 경우 폴더를 생성
		if (!Directory.Exists(targetPath)) {
			Directory.CreateDirectory(targetPath);
		}
		// 원본 폴더가 존재하는지 확인
		if (Directory.Exists(sourcePath)) {
			// sourcePath에서 dataFiles 패턴에 맞는 파일들을 가져옴
			string[] files = Directory.GetFiles(sourcePath, dataFiles);
			string[] array = files;
			// 가져온 파일들을 하나씩 처리
			foreach (string file_source_one in files) {
				try {
					// 현재 처리 중인 파일의 정보를 fileInfo 객체에 저장
					fileInfo = new FileInfo(file_source_one);
					// 파일의 마지막 수정 시간이 targetDate보다 이후인지 확인
					if (fileInfo.LastWriteTime > targetDate)
					{
						// 파일 이름만 추출 (경로 제거)
						path = Path.GetFileName(file_source_one);
						// 대상 경로에 파일 이름을 더해 최종 대상 경로를 만듦
						string file_target_one = Path.Combine(targetPath, path);
						// 원본 파일을 대상 경로에 복사 (덮어쓰기 가능)
						File.Copy(file_source_one, file_target_one, overwrite: true);
						// 성공적으로 복사된 파일 정보 출력
						Console.WriteLine("{0} : {1}", fileInfo.Name, fileInfo.Directory);
					}
					else
					{
						// 지정된 날짜 이전의 파일일 경우 "Old Files"로 출력
						Console.WriteLine("{0} : {1}", fileInfo.Name, "Old Files");
					}
				}
				// 파일을 찾을 수 없는 경우 예외 처리
				catch (FileNotFoundException ex) {
					// 예외 메시지를 로그에 기록
					WriteLog(ex.Message, null);
					// 콘솔에 예외 메시지 출력
					Console.WriteLine(ex.Message);
				}
			}
		}
		// 원본 폴더가 존재하지 않을 경우 오류 메시지 출력
		else {
			Console.WriteLine("Source path does not exist!");
		}
	}

	// 프로그램 실행 중 발생하는 로그를 파일에 기록하는 메소드
	// msg: 기록할 메시지 내용
	// ex: 예외가 발생한 경우 해당 예외 객체 (Java의 Exception과 동일)
	// using 문을 사용하여 자동으로 리소스를 해제 (Java의 try-with-resources와 유사)
	private static void WriteLog(string msg, Exception ex) {

		// 설정 파일에서 로그 경로를 읽어옴
		string text = ConfigurationManager.AppSettings["LogPath"];
		// 로그 경로가 존재하지 않는다면 폴더 생성
		if (!Directory.Exists(text)) {
			Directory.CreateDirectory(text);
		}

		// 현재 년월을 사용하여 로그 파일명을 생성 (예: FileCopy_202304.log)
		string path = text + "\\FileCopy_" + DateTime.Now.ToString("yyyyMM") + ".log";
		// 로그 파일에 정보를 추가하기 위해 StreamWriter 객체 생성 (append: true는 기존 내용 뒤에 추가)
		using StreamWriter streamWriter = new StreamWriter(path, append: true);
		// 현재 시간을 년월일 시분초 형식으로 기록
		streamWriter.WriteLine("[Time  ] " + DateTime.Now.ToString("yyyyMMdd HH:mm:ss"));
		// msg 파라미터가 비어있지 않다면 메시지를 기록
		if (msg != "") {
			streamWriter.WriteLine(msg);
		}

		// ex 파라미터가 null이 아니라면 예외 정보를 기록
		if (ex != null) {
			// 예외 발생 소스 정보 기록
			streamWriter.WriteLine("[Source   ] " + ex.Source.ToString());
			// 예외 메시지 기록
			streamWriter.WriteLine("[Message  ] " + ex.Message);
			// 예외 발생 위치(StackTrace) 정보 기록
			streamWriter.WriteLine("[Location ] " + ex.StackTrace);
		}

		// 로그 구분을 위해 빈 줄 추가
		streamWriter.WriteLine();
		// StreamWriter 객체 닫기 (using문을 사용했기 때문에 자동으로 해제됨)
		streamWriter.Close();

	}
	
}
