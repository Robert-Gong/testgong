// MigMySQL 프로그램의 메인 진입점입니다. 
// 사용자의 컴퓨터 정보(호스트 이름, IP 주소, 사용자 ID)를 확인하여 
// 허용된 사용자인지 확인하고, GUI 모드 또는 명령행 모드로 작동합니다.
using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using PMK.Common;

namespace MigMySQL;

internal static class Program {
	// 프로그램의 메인 함수입니다. 
	// 명령줄 인수를 확인하여 GUI 모드 또는 커맨드 라인 모드로 동작합니다.
	// GUI 모드일 경우, 사용자의 접근 권한을 검증한 후 Form2를 실행합니다.
	// 명령행 모드일 경우, AUTOGET 또는 AUTOSAVE 명령어를 처리합니다.
	[STAThread]
	private static void Main(string[] args) {
		// CheckUserid(), CheckIP(), CheckHostName() 중 하나라도 True면 접근 허용
		bool flag = CheckUserid() || CheckIP() || CheckHostName();
		// 명령줄 인수가 없으면 GUI 모드로 실행
		if (args.Length == 0) {
			// 접근 권한이 없으면 메시지 박스 출력 후 종료
			if (!flag) {
				MessageBox.Show("사용 권한이 없습니다", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return;
			}
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(defaultValue: false);
			Application.Run(new Form2());
			return;
		}
		// 명령줄 인수가 있는 경우 (명령행 모드)
		// 접근 권한이 없으면 로그 기록 후 종료
		if (!flag) {
			LogFile.WriteLog("[IRIS] 사용 권한이 없습니다");
			return;
		}
		try
		{
			// 인수의 첫 번째 값이 AUTOGET이면 Form2의 AUTOGET 메서드 실행
			// 무조건
			if (args[0] == "AUTOGET") {
				Form2.AUTOGET();
			}
			// 인수의 첫 번째 값이 AUTOSAVE이면 Form2의 AUTOSAVE 메서드 실행
			else if (args[0] == "AUTOSAVE") {
				Form2.AUTOSAVE();
			}
			// 잘못된 인수면 로그 기록
			else
			{
				LogFile.WriteLog("[IRIS] 파라미터 오류 - AUTOGET, AUTOSAVE만 가능");
			}
		}
		// 예외 발생 시 로그 기록
		catch (Exception ex) {
			LogFile.WriteLog(ex);
		}
	}

	// 호스트 이름이 특정 키워드를 포함하는지 확인합니다.
	// 이 키워드들은 승인된 시스템을 나타냅니다.
	private static bool CheckHostName() {
		string text = Environment.MachineName.ToUpper();
		// PMIKRSELSQL, PMIKRSELIIS, PMIKRSELAPP, PMIKRSELDEV 중 하나라도 포함되면 True 반환
		return text.IndexOf("PMIKRSELSQL") != -1 || text.IndexOf("PMIKRSELIIS") != -1 || text.IndexOf("PMIKRSELAPP") != -1 || text.IndexOf("PMIKRSELDEV") != -1;
	}

	// 현재 사용자 ID가 승인 목록에 있는지 확인합니다.
	// 승인된 사용자 ID는 HSDOH, CSHIM, AHAN2, MKIM3, SJANG9입니다.
	private static bool CheckUserid() {
		string text = Environment.UserName.ToUpper();
		int result;
		// Switch문으로 사용자 ID를 비교합니다.
		switch (text) {
		// 승인된 사용자 ID가 아닌 경우
		default:
			// SYUN7인 경우에만 True 반환
			result = ((text == "SYUN7") ? 1 : 0);
			break;
		// 승인된 사용자 ID 목록
		case "HSDOH":
		case "CSHIM":
		case "AHAN2":
		case "MKIM3":
		case "SJANG9":
			result = 1;
			break;
		}
		// 결과가 1이면 True, 0이면 False 반환
		return (byte)result != 0;
	}

	// 현재 컴퓨터의 IP 주소가 승인된 IP 주소인지 확인합니다.
	// 승인된 IP 주소는 211.117.28.138, 211.177.31.146, 118.130.133.29입니다.
	private static bool CheckIP() {
		IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
		for (int i = 0; i < hostEntry.AddressList.Length; i++) {
			// IPv4 주소이고, 승인된 IP 주소와 일치하면 True 반환
			if (hostEntry.AddressList[i].AddressFamily == AddressFamily.InterNetwork && (hostEntry.AddressList[i].ToString() == "211.117.28.138" || hostEntry.AddressList[i].ToString() == "211.177.31.146" || hostEntry.AddressList[i].ToString() == "118.130.133.29")) {
				return true;
			}
		}
		// 위 조건에 해당하지 않으면 False 반환
		return false;
	}
}
