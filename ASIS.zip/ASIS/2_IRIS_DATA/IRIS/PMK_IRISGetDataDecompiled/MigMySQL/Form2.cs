using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using PMK.Common;

namespace MigMySQL;

public class Form2 : Form
{
	private DataTable dtIRISColumns;

	private string mssqlconnIRIS;

	private string mssqlconnPMK;

	private ArrayList arrayMasterTList;

	private ArrayList arrayIncludeList;

	private static byte[] key = new byte[8] { 107, 108, 109, 110, 110, 109, 108, 107 };

	public static Dictionary<string, string> al = new Dictionary<string, string>();

	private IContainer components = null;

	private SplitContainer splitContainer1;

	private Panel panel1;

	private Label label1;

	private Label label2;

	private TreeView tView;

	private DateTimePicker dateFrom;

	private Label label4;

	private DateTimePicker dateTo;

	private Label label5;

	private Label lblMySql;

	private Label lblMSSql;

	private Button button1;

	private DataGridView dgv;

	private CheckBox chbA;

	private Label label3;

	private RadioButton radioButton1;

	private RadioButton radioButton2;

	private Button button2;

	private Button button3;

	private CheckBox chbD;

	private CheckBox chbM;

	private Panel panel2;

	private CheckBox cbEncript;

	public Form2()
	{
		InitializeComponent();
	}

	private void Form2_Load(object sender, EventArgs e)
	{
		label2.Text = DateTime.Now.ToString("[yyyy-MM-dd]");
		dateFrom.Value = DateTime.Now.AddDays(-1.0);
		dateTo.Value = DateTime.Now.AddDays(-1.0);
		arrayMasterTList = new ArrayList();
		arrayMasterTList.Add("CATEGORIES");
		arrayMasterTList.Add("CHARACTERS");
		arrayMasterTList.Add("COMMON_D");
		arrayMasterTList.Add("DISCOUNTS");
		arrayMasterTList.Add("PRODUCT_CATEGORIES");
		arrayMasterTList.Add("PRODUCTS");
		arrayMasterTList.Add("SHOP_BRANCHES");
		arrayMasterTList.Add("SHOP_GROUPS");
		arrayMasterTList.Add("SHOPS");
		arrayMasterTList.Add("CALLCARD_ANS_GRP_D");
		arrayMasterTList.Add("CALLCARD_ANS_GRP_H");
		arrayMasterTList.Add("CALLCARD_ANS_TP");
		arrayMasterTList.Add("CALLCARD_APPLY_SHOP");
		arrayMasterTList.Add("CALLCARD_MST_D");
		arrayMasterTList.Add("CALLCARD_MST_H");
		arrayIncludeList = new ArrayList();
		arrayIncludeList.Add("CATEGORIES");
		arrayIncludeList.Add("CHARACTERS");
		arrayIncludeList.Add("COMMON_D");
		arrayIncludeList.Add("COUPONS");
		arrayIncludeList.Add("DISCOUNTS");
		arrayIncludeList.Add("ORDER_PRODUCTS");
		arrayIncludeList.Add("ORDERS");
		arrayIncludeList.Add("PRODUCT_CATEGORIES");
		arrayIncludeList.Add("PRODUCTS");
		arrayIncludeList.Add("SHOP_BRANCHES");
		arrayIncludeList.Add("SHOP_GROUPS");
		arrayIncludeList.Add("SHOPS");
		arrayIncludeList.Add("VISITOR_CHARACTERS");
		arrayIncludeList.Add("CONSUMED_COUPONS");
		arrayIncludeList.Add("CALLCARD_ANS_GRP_D");
		arrayIncludeList.Add("CALLCARD_ANS_GRP_H");
		arrayIncludeList.Add("CALLCARD_ANS_TP");
		arrayIncludeList.Add("CALLCARD_ANSWERS");
		arrayIncludeList.Add("CALLCARD_APPLY_SHOP");
		arrayIncludeList.Add("CALLCARD_MST_D");
		arrayIncludeList.Add("CALLCARD_MST_H");
		arrayIncludeList.Add("ORDER_COUPON");
		arrayIncludeList.Add("CONSUMER");
		arrayIncludeList.Add("CHARACTERS_Q");
		arrayIncludeList.Add("CHARACTERS_A");
		arrayIncludeList.Add("HASHTAG");
		arrayIncludeList.Add("HASHTAG_PRODUCT");
		arrayIncludeList.Add("TIMESTAMPS_FCM");
		arrayIncludeList.Add("TIMESTAMPS");
		arrayIncludeList.Add("VISITOR_CHARACTERS_NEW");
		arrayIncludeList.Add("VISITORS");
		arrayIncludeList.Add("PERFORMANCES");
		arrayIncludeList.Add("SHOP_BRANCH_SF");
		arrayMasterTList.Add("CHARACTERS_Q");
		arrayMasterTList.Add("CHARACTERS_A");
		arrayMasterTList.Add("HASHTAG");
		arrayMasterTList.Add("HASHTAG_PRODUCT");
		arrayMasterTList.Add("TIMESTAMPS_FCM");
		arrayMasterTList.Add("SHOP_BRANCH_SF");
		rb_CheckedChanged(radioButton1, EventArgs.Empty);
	}

	private void rb_CheckedChanged(object sender, EventArgs e)
	{
		RadioButton radioButton = sender as RadioButton;
		if (!radioButton.Checked)
		{
			return;
		}
		string text = ConfigurationManager.AppSettings["DBSERVER"].ToString();
		label1.Text = $"[{text}] 서버";
		lblMySql.Text = $"[{text}] 서버 Table";
		MSSQLConStr(text, ref mssqlconnIRIS, ref mssqlconnPMK);
		if (string.IsNullOrEmpty(mssqlconnIRIS) || string.IsNullOrEmpty(mssqlconnPMK))
		{
			MessageBox.Show("Connection 정보가 존재하지 않습니다.");
			return;
		}
		if (dtIRISColumns != null)
		{
			dtIRISColumns.Clear();
		}
		tView.Nodes.Clear();
		SqlConnection sqlConnection = new SqlConnection(mssqlconnIRIS);
		try
		{
			sqlConnection.Open();
			DataTable schema = sqlConnection.GetSchema("Tables");
			dtIRISColumns = sqlConnection.GetSchema("Columns");
			ArrayList arrayList = new ArrayList();
			foreach (DataRow row in schema.Rows)
			{
				arrayList.Add(row["TABLE_NAME"].ToString());
			}
			schema = dtIRISColumns.DefaultView.ToTable(true, "TABLE_NAME");
			foreach (DataRow row2 in schema.Rows)
			{
				if (arrayList.Contains(row2["TABLE_NAME"].ToString()) && arrayIncludeList.IndexOf(row2["TABLE_NAME"].ToString().ToUpper().Trim()) != -1)
				{
					tView.Nodes.Add(" " + row2["TABLE_NAME"].ToString());
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
		finally
		{
			sqlConnection.Close();
		}
	}

	private void chb_CheckedChanged(object sender, EventArgs e)
	{
		chbA.CheckedChanged -= chb_CheckedChanged;
		chbM.CheckedChanged -= chb_CheckedChanged;
		chbD.CheckedChanged -= chb_CheckedChanged;
		CheckBox checkBox = sender as CheckBox;
		if (checkBox.Name == "chbA")
		{
			CheckBox checkBox2 = chbM;
			bool flag = (chbD.Checked = false);
			checkBox2.Checked = flag;
			foreach (TreeNode node in tView.Nodes)
			{
				node.Checked = checkBox.Checked;
			}
		}
		else
		{
			foreach (TreeNode node2 in tView.Nodes)
			{
				node2.Checked = false;
			}
			if (checkBox.Name == "chbM")
			{
				CheckBox checkBox3 = chbA;
				bool flag = (chbD.Checked = false);
				checkBox3.Checked = flag;
				foreach (TreeNode node3 in tView.Nodes)
				{
					if (arrayMasterTList.IndexOf(node3.Text.ToUpper().Trim()) != -1)
					{
						node3.Checked = checkBox.Checked;
					}
				}
			}
			else
			{
				CheckBox checkBox4 = chbA;
				bool flag = (chbM.Checked = false);
				checkBox4.Checked = flag;
				foreach (TreeNode node4 in tView.Nodes)
				{
					if (arrayMasterTList.IndexOf(node4.Text.ToUpper().Trim()) == -1)
					{
						node4.Checked = checkBox.Checked;
					}
				}
			}
		}
		chbA.CheckedChanged += chb_CheckedChanged;
		chbM.CheckedChanged += chb_CheckedChanged;
		chbD.CheckedChanged += chb_CheckedChanged;
	}

	private void InsertToPMK(string tablename)
	{
		try
		{
			SqlParameter[] array = new SqlParameter[1]
			{
				new SqlParameter("TABLE_NAME", SqlDbType.VarChar, 100)
			};
			array[0].Value = tablename;
			using SqlCommand sqlCommand = new SqlCommand("UpdateIRISDatas", new SqlConnection(mssqlconnPMK));
			sqlCommand.CommandType = CommandType.StoredProcedure;
			sqlCommand.Parameters.AddRange(array);
			sqlCommand.Connection.Open();
			sqlCommand.ExecuteNonQuery();
			sqlCommand.Connection.Close();
		}
		catch (SqlException ex)
		{
			throw new Exception(ex.ToString());
		}
	}

	private void button1_Click(object sender, EventArgs e)
	{
		DataTable dataTable = new DataTable();
		dataTable.Columns.Add(new DataColumn("TABLE_NAME", typeof(string)));
		dataTable.Columns.Add(new DataColumn("RESULT", typeof(string)));
		dataTable.Columns.Add(new DataColumn("COUNT", typeof(string)));
		foreach (TreeNode node in tView.Nodes)
		{
			if (node.Checked)
			{
				DataRow dataRow = dataTable.NewRow();
				dataRow["TABLE_NAME"] = node.Text.Trim();
				dataTable.Rows.Add(dataRow);
			}
		}
		string dateF = dateFrom.Value.ToString("yyyy-MM-dd");
		string dateT = dateTo.Value.ToString("yyyy-MM-dd");
		foreach (DataRow row in dataTable.Rows)
		{
			string text = row["TABLE_NAME"].ToString().Replace(" ", "");
			DataRow[] array = dtIRISColumns.Select($"TABLE_NAME='{text}'");
			if (array.Length == 0)
			{
				row["RESULT"] = "테이블이 존재하지 않음";
				continue;
			}
			try
			{
				DataTable dataTable2 = null;
				bool flag = false;
				foreach (object arrayMasterT in arrayMasterTList)
				{
					if (arrayMasterT.ToString() == text.ToUpper())
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					dataTable2 = Select(text, dateF, dateT, flag);
					DeleteData(text, dateF, dateT, flag);
				}
				else
				{
					array = dtIRISColumns.Select($"TABLE_NAME='{text}' AND (COLUMN_NAME = 'updated_at' OR COLUMN_NAME = 'create_at')");
					if (array.Length != 0)
					{
						dataTable2 = Select(text, dateF, dateT, flag);
						if (dataTable2.Rows.Count > 0)
						{
							DeleteData(text, dateF, dateT, isMaster: false);
						}
					}
				}
				InsertToPMK(text);
				row["RESULT"] = "작업 완료";
				row["COUNT"] = dataTable2.Rows.Count.ToString("#,##0") + "건 이관";
			}
			catch (Exception ex)
			{
				row["RESULT"] = "오류발생 : " + ex.ToString();
			}
		}
		dgv.DataSource = dataTable;
		foreach (DataGridViewColumn column in dgv.Columns)
		{
			column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
		}
		MessageBox.Show("작업을 완료 하였습니다", "[" + Text + "]실행 완료", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
	}

	private void button2_Click(object sender, EventArgs e)
	{
		ArrayList arrayList = new ArrayList();
		foreach (TreeNode node in tView.Nodes)
		{
			if (node.Checked)
			{
				arrayList.Add(node.Text.Replace(" ", ""));
			}
		}
		string selectCommandText = "";
		string text = dateFrom.Value.ToString("yyyyMMdd");
		string text2 = dateTo.Value.ToString("yyyyMMdd");
		LogFile.WriteLog("[IRIS START] IRIS->File ###############################################");
		foreach (string item in arrayList)
		{
			bool flag = false;
			try
			{
				DataSet dataSet = new DataSet();
				foreach (object arrayMasterT in arrayMasterTList)
				{
					if (arrayMasterT.ToString() == item.ToUpper())
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					selectCommandText = $"\r\n    SELECT * \r\n    FROM iris.{item} ; ";
				}
				else
				{
					DataRow[] array = dtIRISColumns.Select($"TABLE_NAME='{item}' AND COLUMN_NAME = 'updated_at' ");
					if (array.Length != 0)
					{
						selectCommandText = string.Format("\r\nSELECT * \r\nFROM iris.{0} \r\nWHERE (CONVERT(VARCHAR(10), updated_at, 112) >= '{1}' AND CONVERT(VARCHAR(10), updated_at, 112) <= '{2}')\r\nOR(CONVERT(VARCHAR(10), created_at, 112) >= '{1}' AND CONVERT(VARCHAR(10), created_at, 112) <= '{2}'); ", item, text, text2);
					}
				}
				using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(selectCommandText, mssqlconnIRIS))
				{
					sqlDataAdapter.SelectCommand.CommandTimeout = 0;
					sqlDataAdapter.Fill(dataSet);
					dataSet.Tables[0].TableName = item;
				}
				SaveFile(item, text, text2, dataSet, cbEncript.Checked);
				LogFile.WriteLog("[IRIS], [" + text + "~" + text2 + "] [" + item + "] 파일저장");
			}
			catch (Exception ex)
			{
				LogFile.WriteLog("[IRIS ERROR] IRIS->File ###############################################");
				LogFile.WriteLog(ex);
			}
		}
		LogFile.WriteLog("[IRIS   END] IRIS->File ###############################################");
		MessageBox.Show($"{label1.Text}->File 작업을 완료 하였습니다", "[" + Text + "]실행 완료", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
	}

	private void button3_Click(object sender, EventArgs e)
	{
		DataTable dataTable = null;
		SqlConnection sqlConnection = new SqlConnection(mssqlconnPMK);
		try
		{
			sqlConnection.Open();
			dataTable = sqlConnection.GetSchema("Columns");
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
			return;
		}
		finally
		{
			sqlConnection.Close();
		}
		LogFile.WriteLog("[IRIS START] File->PMK ###############################################");
		string path = ConfigurationManager.AppSettings["DATAFILEPATH"];
		DirectoryInfo directoryInfo = new DirectoryInfo(path);
		FileInfo[] files = directoryInfo.GetFiles("*#schema.xml");
		FileInfo[] array = files;
		foreach (FileInfo fileInfo in array)
		{
			string[] array2 = fileInfo.Name.Split('#');
			string text = array2[1];
			string text2 = array2[2];
			string text3 = array2[3];
			bool flag = false;
			try
			{
				foreach (object arrayMasterT in arrayMasterTList)
				{
					if (arrayMasterT.ToString() == text.ToUpper())
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					DeleteData(text, text2, text3, flag);
				}
				else
				{
					DataRow[] array3 = dataTable.Select($"TABLE_NAME='{text}' AND COLUMN_NAME = 'updated_at' ");
					if (array3.Length != 0)
					{
						DeleteData(text, text2, text3, isMaster: false);
					}
				}
				string fullName = fileInfo.FullName;
				DataSet dataSet = new DataSet();
				dataSet.ReadXmlSchema(fullName);
				dataSet.ReadXml(fullName.Replace("#schema", "#data"));
				BulkCopy(dataSet.Tables[0]);
				dataSet.Dispose();
				fileInfo.Delete();
				File.Delete(fullName.Replace("#schema", "#data"));
				LogFile.WriteLog("[IRIS], [" + text2 + "~" + text3 + "] [" + text + "] 파일작업 완료");
			}
			catch (Exception ex2)
			{
				LogFile.WriteLog("[IRIS ERROR] File->PMK ###############################################");
				LogFile.WriteLog(ex2);
			}
		}
		LogFile.WriteLog("[IRIS   END] File->PMK ###############################################");
		MessageBox.Show($"File -> {label1.Text} 작업을 완료 하였습니다", "[" + Text + "]실행 완료", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
	}

	private DataTable Select(string tablename, string dateF, string dateT, bool isMaster)
	{
		DataSet dataSet = new DataSet();
		DataTable dataTable = new DataTable();
		try
		{
			string empty = string.Empty;
			empty = ((!isMaster) ? string.Format("\r\nSELECT * \r\nFROM iris.{0} \r\nWHERE (CONVERT(VARCHAR(10), updated_at, 121) >= '{1}' AND CONVERT(VARCHAR(10), updated_at, 121) <= '{2}')\r\nOR(CONVERT(VARCHAR(10), created_at, 121) >= '{1}' AND CONVERT(VARCHAR(10), created_at, 121) <= '{2}')", tablename, dateF, dateT) : $"\r\nSELECT * \r\nFROM iris.{tablename}");
			using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(empty, mssqlconnIRIS))
			{
				sqlDataAdapter.SelectCommand.CommandTimeout = 0;
				sqlDataAdapter.Fill(dataSet);
				dataSet.Tables[0].TableName = tablename;
			}
			dataTable = dataSet.Tables[0];
			dataTable.TableName = dataSet.Tables[0].TableName;
			dataSet.Tables[0].TableName = $"GetData_{dataSet.Tables[0].TableName}";
			DeleteGetData(dataSet.Tables[0].TableName);
			BulkCopy(dataSet.Tables[0]);
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
		return dataTable;
	}

	private bool DeleteGetData(string tablename)
	{
		try
		{
			if (!tablename.Contains("GetData"))
			{
				return false;
			}
			string cmdText = $"DELETE  {tablename}";
			using SqlCommand sqlCommand = new SqlCommand(cmdText, new SqlConnection(mssqlconnPMK));
			sqlCommand.CommandType = CommandType.Text;
			sqlCommand.Connection.Open();
			sqlCommand.ExecuteNonQuery();
			sqlCommand.Connection.Close();
		}
		catch (SqlException ex)
		{
			MessageBox.Show(ex.Message);
			return false;
		}
		return true;
	}

	private bool DeleteData(string tableName, string dateF, string dateT, bool isMaster)
	{
		try
		{
			SqlParameter[] array = new SqlParameter[4]
			{
				new SqlParameter("TABLE_NAME", SqlDbType.VarChar, 100),
				new SqlParameter("FR", SqlDbType.VarChar, 10),
				new SqlParameter("TO", SqlDbType.VarChar, 10),
				new SqlParameter("IS_MASTER", SqlDbType.Bit)
			};
			array[0].Value = tableName;
			array[1].Value = dateF;
			array[2].Value = dateT;
			array[3].Value = isMaster;
			using SqlCommand sqlCommand = new SqlCommand("DeleteIRISDatas", new SqlConnection(mssqlconnPMK));
			sqlCommand.CommandType = CommandType.StoredProcedure;
			sqlCommand.Parameters.AddRange(array);
			sqlCommand.Connection.Open();
			sqlCommand.ExecuteNonQuery();
			sqlCommand.Connection.Close();
		}
		catch (SqlException ex)
		{
			MessageBox.Show(ex.Message);
			return false;
		}
		return true;
	}

	private void BulkCopy(DataTable dt)
	{
		using SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(mssqlconnPMK);
		try
		{
			sqlBulkCopy.BatchSize = dt.Rows.Count;
			sqlBulkCopy.DestinationTableName = dt.TableName;
			sqlBulkCopy.WriteToServer(dt);
		}
		catch (Exception ex)
		{
			MessageBox.Show($"테이블명 : [{dt.TableName}] : " + ex.Message);
		}
	}

	private static void ToEncryptFile(string filename, string str)
	{
		try
		{
			using ICryptoTransform transform = new DESCryptoServiceProvider
			{
				Key = key,
				IV = key
			}.CreateEncryptor();
			using FileStream stream = new FileStream(filename, FileMode.Create, FileAccess.Write);
			using CryptoStream cryptoStream = new CryptoStream(stream, transform, CryptoStreamMode.Write);
			byte[] bytes = Encoding.UTF8.GetBytes(str);
			cryptoStream.Write(bytes, 0, bytes.Length);
		}
		catch (Exception ex)
		{
			throw ex;
		}
	}

	private static void Decrypt(string filename)
	{
		string value = "";
		try
		{
			using (ICryptoTransform transform = new DESCryptoServiceProvider
			{
				Key = key,
				IV = key
			}.CreateDecryptor())
			{
				using FileStream stream = new FileStream(filename, FileMode.Open, FileAccess.Read);
				using CryptoStream stream2 = new CryptoStream(stream, transform, CryptoStreamMode.Read);
				using StreamReader streamReader = new StreamReader(stream2);
				value = streamReader.ReadToEnd();
			}
			using StreamWriter streamWriter = new StreamWriter(filename);
			streamWriter.WriteLine(value);
			streamWriter.Close();
		}
		catch (Exception ex)
		{
			throw ex;
		}
	}

	public static void GetDictionaryTable()
	{
		al.Clear();
		al.Add("categories", "M");
		al.Add("characters", "M");
		al.Add("common_d", "M");
		al.Add("coupons", "D");
		al.Add("discounts", "M");
		al.Add("order_products", "D");
		al.Add("orders", "D");
		al.Add("product_categories", "M");
		al.Add("products", "M");
		al.Add("shop_branches", "M");
		al.Add("shop_groups", "M");
		al.Add("shops", "M");
		al.Add("visitor_characters", "D");
		al.Add("consumed_coupons", "D");
		al.Add("callcard_ans_grp_d", "M");
		al.Add("callcard_ans_grp_h", "M");
		al.Add("callcard_ans_tp", "M");
		al.Add("callcard_answers", "D");
		al.Add("callcard_apply_shop", "M");
		al.Add("callcard_mst_d", "M");
		al.Add("callcard_mst_h", "M");
		al.Add("order_coupon", "D");
		al.Add("consumer", "D");
		al.Add("timestamps_fcm", "M");
		al.Add("timestamps", "D");
		al.Add("characters_q", "M");
		al.Add("characters_a", "M");
		al.Add("visitor_characters_new", "D");
		al.Add("visitors", "D");
		al.Add("performances", "D");
		al.Add("hashtag", "M");
		al.Add("hashtag_product", "M");
		al.Add("shop_branch_sf", "M");
	}

	public static void AUTOGET()
	{
		GetDictionaryTable();
		Dictionary<string, string> dictionary = new Dictionary<string, string>();
		DataTable dataTable = null;
		string stage = ConfigurationManager.AppSettings["DBSERVER"].ToString();
		string strIRIS = string.Empty;
		string strPMK = string.Empty;
		MSSQLConStr(stage, ref strIRIS, ref strPMK);
        SqlConnection sqlConnection = new SqlConnection(strIRIS);
		try
		{
			sqlConnection.Open();
			DataTable schema = sqlConnection.GetSchema("Tables");
			dataTable = sqlConnection.GetSchema("Columns");
			schema = dataTable.DefaultView.ToTable(true, "TABLE_NAME");
			foreach (DataRow row in schema.Rows)
			{
				foreach (KeyValuePair<string, string> item in al)
				{
					if (item.Key.ToUpper() == row["TABLE_NAME"].ToString().ToUpper())
					{
						dictionary.Add(row["TABLE_NAME"].ToString(), item.Value);
					}
				}
			}
		}
		catch (Exception ex)
		{
			LogFile.WriteLog("[IRIS ERROR] AUTOGET() ###############################################");
			LogFile.WriteLog(ex);
			return;
		}
		finally
		{
			sqlConnection.Close();
		}
		string text = "";
		string text2 = DateTime.Now.AddDays(-1.0).ToString("yyyyMMdd");
		LogFile.WriteLog("[IRIS START] AUTOGET() ###############################################");
		foreach (KeyValuePair<string, string> item2 in dictionary)
		{
			try
			{
				DataRow[] array = dataTable.Select($"TABLE_NAME='{item2.Key}' AND COLUMN_NAME = 'updated_at' ");
				DataSet dataSet = new DataSet();
				if (item2.Value == "M")
				{
					text = $"\r\nSELECT * FROM iris.{item2.Key} ";
				}
				else if (array.Length != 0)
				{
					text = string.Format("\r\nSELECT * \r\nFROM iris.{0} \r\nWHERE (CONVERT(VARCHAR(8), updated_at, 112) >= '{1}' AND CONVERT(VARCHAR(8), updated_at, 112) <= '{2}')\r\nOR(CONVERT(VARCHAR(8), created_at, 112) >= '{1}' AND CONVERT(VARCHAR(8), created_at, 112) <= '{2}'); ", item2.Key, text2, text2);
				}
				if (string.IsNullOrEmpty(text))
				{
					throw new Exception();
				}
				using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(text, strIRIS))
				{
					sqlDataAdapter.SelectCommand.CommandTimeout = 0;
					sqlDataAdapter.Fill(dataSet);
					dataSet.Tables[0].TableName = item2.Key.ToString();
				}
				SaveFile(item2.Key.ToString(), text2, text2, dataSet, encript: true);
				LogFile.WriteLog("[IRIS], [" + text2 + "] [" + item2.Key + "] 파일저장");
				GC.Collect();
			}
			catch (Exception ex2)
			{
				LogFile.WriteLog("[IRIS ERROR] AUTOGET() - [" + item2.Key + "] ######################################");
				LogFile.WriteLog(ex2);
			}
		}
		LogFile.WriteLog("[IRIS   END] AUTOGET() ###############################################");
	}

	public static void AUTOSAVE()
	{
		GetDictionaryTable();
		DataTable dataTable = null;
		string strIRIS = string.Empty;
		string strPMK = string.Empty;
		string stage = ConfigurationManager.AppSettings["DBSERVER"].ToString();
		MSSQLConStr(stage, ref strIRIS, ref strPMK);
		SqlConnection sqlConnection = new SqlConnection(strPMK);
		try
		{
			sqlConnection.Open();
			dataTable = sqlConnection.GetSchema("Columns");
		}
		catch (Exception ex)
		{
			LogFile.WriteLog("[IRIS ERROR] AUTOSAVE() ###############################################");
			LogFile.WriteLog(ex);
			return;
		}
		finally
		{
			sqlConnection.Close();
		}
		LogFile.WriteLog("[IRIS START] AUTOSAVE() File->PMK ###############################################");
		string path = ConfigurationManager.AppSettings["DATAFILEPATH"];
		DirectoryInfo directoryInfo = new DirectoryInfo(path);
		FileInfo[] files = directoryInfo.GetFiles("*#schema.xml");
		FileInfo[] array = files;
		foreach (FileInfo fileInfo in array)
		{
			string name = fileInfo.Name;
			string[] array2 = name.Split('#');
			string text = array2[1];
			string text2 = array2[2];
			string text3 = array2[3];
			try
			{
				bool flag = false;
				foreach (KeyValuePair<string, string> item in al)
				{
					if (item.Key.ToUpper() == text.ToUpper() && item.Value == "M")
					{
						flag = true;
						break;
					}
				}
				DataRow[] array3 = dataTable.Select($"TABLE_NAME='{text}' AND COLUMN_NAME = 'updated_at' ");
				if (!(array3.Length != 0 || flag))
				{
					continue;
				}
				Command_DeleteData("GetData_" + text);
				string fullName = fileInfo.FullName;
				Decrypt(fullName);
				Decrypt(fullName.Replace("#schema", "#data"));
				using (DataSet dataSet = new DataSet())
				{
					dataSet.ReadXmlSchema(fullName);
					dataSet.ReadXml(fullName.Replace("#schema", "#data"));
					using SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(strPMK);
					try
					{
						sqlBulkCopy.BatchSize = dataSet.Tables[0].Rows.Count;
						sqlBulkCopy.DestinationTableName = "GetData_" + dataSet.Tables[0].TableName;
						sqlBulkCopy.WriteToServer(dataSet.Tables[0]);
						Command_DeleteData(text, text2, text3);
						Command_InsertToPMK(dataSet.Tables[0].TableName);
					}
					catch (Exception ex2)
					{
						MessageBox.Show(ex2.Message);
					}
				}
				fileInfo.Delete();
				File.Delete(fullName.Replace("#schema", "#data"));
				GC.Collect();
				LogFile.WriteLog("[IRIS], [" + text2 + "~" + text3 + "] [" + text + "] 파일->PMK 업로드 완료");
			}
			catch (Exception ex3)
			{
				LogFile.WriteLog("[IRIS ERROR] AUTOSAVE() File->PMK - [" + text + "] ##############################");
				LogFile.WriteLog(ex3);
			}
		}
		LogFile.WriteLog("[IRIS   END] AUTOSAVE() File->PMK ###############################################");
	}

	private static void SaveFile(string tbname, string dateF, string dateT, DataSet ds, bool encript)
	{
		string str = "";
		string text = ConfigurationManager.AppSettings["DATAFILEPATH"];
		if (!Directory.Exists(text))
		{
			Directory.CreateDirectory(text);
		}
		string text2 = text + "PMKIRIS#" + tbname + "#" + dateF + "#" + dateT + "#schema.xml";
		ds.WriteXmlSchema(text2);
		using (StreamReader streamReader = new StreamReader(text2))
		{
			str = streamReader.ReadToEnd();
			streamReader.Close();
		}
		if (encript)
		{
			ToEncryptFile(text2, str);
		}
		text2 = text + "PMKIRIS#" + tbname + "#" + dateF + "#" + dateT + "#data.xml";
		ds.WriteXml(text2);
		using (StreamReader streamReader2 = new StreamReader(text2))
		{
			str = streamReader2.ReadToEnd();
			streamReader2.Close();
		}
		if (encript)
		{
			ToEncryptFile(text2, str);
		}
	}

	private static void Command_InsertToPMK(string tablename)
	{
		try
		{
			string strIRIS = string.Empty;
			string strPMK = string.Empty;
			string stage = ConfigurationManager.AppSettings["DBSERVER"].ToString();
			MSSQLConStr(stage, ref strIRIS, ref strPMK);
			SqlParameter[] array = new SqlParameter[1]
			{
				new SqlParameter("TABLE_NAME", SqlDbType.VarChar, 100)
			};
			array[0].Value = tablename;
			using SqlCommand sqlCommand = new SqlCommand("UpdateIRISDatas", new SqlConnection(strPMK));
			sqlCommand.CommandType = CommandType.StoredProcedure;
			sqlCommand.Parameters.AddRange(array);
			sqlCommand.Connection.Open();
			sqlCommand.ExecuteNonQuery();
			sqlCommand.Connection.Close();
		}
		catch (SqlException ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	private static bool Command_DeleteData(string tableName, string dateF, string dateT)
	{
		try
		{
			foreach (KeyValuePair<string, string> item in al)
			{
				if (item.Key.ToUpper() != tableName.ToUpper())
				{
					continue;
				}
				bool flag = false;
				if (item.Value == "M")
				{
					flag = true;
				}
				SqlParameter[] array = new SqlParameter[4]
				{
					new SqlParameter("TABLE_NAME", SqlDbType.VarChar, 100),
					new SqlParameter("FR", SqlDbType.VarChar, 10),
					new SqlParameter("TO", SqlDbType.VarChar, 10),
					new SqlParameter("IS_MASTER", SqlDbType.Bit)
				};
				array[0].Value = tableName;
				array[1].Value = dateF;
				array[2].Value = dateT;
				array[3].Value = flag;
				string strIRIS = string.Empty;
				string strPMK = string.Empty;
				string stage = ConfigurationManager.AppSettings["DBSERVER"].ToString();
				MSSQLConStr(stage, ref strIRIS, ref strPMK);
				using (SqlCommand sqlCommand = new SqlCommand("DeleteIRISDatas", new SqlConnection(strPMK)))
				{
					sqlCommand.CommandType = CommandType.StoredProcedure;
					sqlCommand.Parameters.AddRange(array);
					sqlCommand.Connection.Open();
					sqlCommand.ExecuteNonQuery();
					sqlCommand.Connection.Close();
				}
				break;
			}
		}
		catch (SqlException ex)
		{
			MessageBox.Show(ex.Message);
			return false;
		}
		return true;
	}

	private static bool Command_DeleteData(string tablename)
	{
		try
		{
			string strIRIS = string.Empty;
			string strPMK = string.Empty;
			string stage = ConfigurationManager.AppSettings["DBSERVER"].ToString();
			MSSQLConStr(stage, ref strIRIS, ref strPMK);
			string cmdText = $"DELETE  {tablename}";
			using SqlCommand sqlCommand = new SqlCommand(cmdText, new SqlConnection(strPMK));
			sqlCommand.CommandType = CommandType.Text;
			sqlCommand.Connection.Open();
			sqlCommand.ExecuteNonQuery();
			sqlCommand.Connection.Close();
		}
		catch (SqlException ex)
		{
			MessageBox.Show(ex.Message);
			return false;
		}
		return true;
	}

	private static void MSSQLConStr(string stage, ref string strIRIS, ref string strPMK)
	{
		switch (stage)
		{
		case "DEV":
			strIRIS = "Data Source=211.50.136.35,9433;Database=corner_shop;uid=sa;pwd=qwer!234";
			strPMK = "Data Source=PMIK11RSELDEV04\\DEV;database=PMK_IRIS;uid=smartweb;pwd=PMKmssdev04";
			break;
		case "QA":
			strIRIS = "Data Source=211.50.136.35,9433;Database=corner_shop;uid=sa;pwd=qwer!234";
			strPMK = "Data Source=PMIKRSELDEV02\\QAS;database=PMK_IRIS;uid=smartweb;pwd=PMKsmartdev02";
			break;
		case "PRD":
			strIRIS = "Data Source=211.50.136.35;Database=corner_shop;uid=pmk_sales;pwd=pmk123$$";
			strPMK = "Data Source=PMIKRSELSQL10\\PRD;Database=PMK_IRIS;uid=smartweb;pwd=financeIS#k8mb";
			break;
		}
	}

	protected override void Dispose(bool disposing)
	{
		if (disposing && components != null)
		{
			components.Dispose();
		}
		base.Dispose(disposing);
	}

	private void InitializeComponent()
	{
		this.splitContainer1 = new System.Windows.Forms.SplitContainer();
		this.tView = new System.Windows.Forms.TreeView();
		this.panel2 = new System.Windows.Forms.Panel();
		this.chbM = new System.Windows.Forms.CheckBox();
		this.chbD = new System.Windows.Forms.CheckBox();
		this.chbA = new System.Windows.Forms.CheckBox();
		this.lblMySql = new System.Windows.Forms.Label();
		this.button3 = new System.Windows.Forms.Button();
		this.button2 = new System.Windows.Forms.Button();
		this.label3 = new System.Windows.Forms.Label();
		this.radioButton1 = new System.Windows.Forms.RadioButton();
		this.radioButton2 = new System.Windows.Forms.RadioButton();
		this.dgv = new System.Windows.Forms.DataGridView();
		this.button1 = new System.Windows.Forms.Button();
		this.lblMSSql = new System.Windows.Forms.Label();
		this.dateFrom = new System.Windows.Forms.DateTimePicker();
		this.label4 = new System.Windows.Forms.Label();
		this.dateTo = new System.Windows.Forms.DateTimePicker();
		this.label5 = new System.Windows.Forms.Label();
		this.panel1 = new System.Windows.Forms.Panel();
		this.label1 = new System.Windows.Forms.Label();
		this.label2 = new System.Windows.Forms.Label();
		this.cbEncript = new System.Windows.Forms.CheckBox();
		((System.ComponentModel.ISupportInitialize)this.splitContainer1).BeginInit();
		this.splitContainer1.Panel1.SuspendLayout();
		this.splitContainer1.Panel2.SuspendLayout();
		this.splitContainer1.SuspendLayout();
		this.panel2.SuspendLayout();
		((System.ComponentModel.ISupportInitialize)this.dgv).BeginInit();
		this.panel1.SuspendLayout();
		base.SuspendLayout();
		this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
		this.splitContainer1.Location = new System.Drawing.Point(0, 57);
		this.splitContainer1.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
		this.splitContainer1.Name = "splitContainer1";
		this.splitContainer1.Panel1.BackColor = System.Drawing.Color.White;
		this.splitContainer1.Panel1.Controls.Add(this.tView);
		this.splitContainer1.Panel1.Controls.Add(this.panel2);
		this.splitContainer1.Panel1.Controls.Add(this.lblMySql);
		this.splitContainer1.Panel2.Controls.Add(this.cbEncript);
		this.splitContainer1.Panel2.Controls.Add(this.button3);
		this.splitContainer1.Panel2.Controls.Add(this.button2);
		this.splitContainer1.Panel2.Controls.Add(this.label3);
		this.splitContainer1.Panel2.Controls.Add(this.radioButton1);
		this.splitContainer1.Panel2.Controls.Add(this.radioButton2);
		this.splitContainer1.Panel2.Controls.Add(this.dgv);
		this.splitContainer1.Panel2.Controls.Add(this.button1);
		this.splitContainer1.Panel2.Controls.Add(this.lblMSSql);
		this.splitContainer1.Panel2.Controls.Add(this.dateFrom);
		this.splitContainer1.Panel2.Controls.Add(this.label4);
		this.splitContainer1.Panel2.Controls.Add(this.dateTo);
		this.splitContainer1.Panel2.Controls.Add(this.label5);
		this.splitContainer1.Panel2.Font = new System.Drawing.Font("맑은 고딕", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 129);
		this.splitContainer1.Size = new System.Drawing.Size(924, 644);
		this.splitContainer1.SplitterDistance = 291;
		this.splitContainer1.SplitterWidth = 11;
		this.splitContainer1.TabIndex = 0;
		this.tView.CheckBoxes = true;
		this.tView.Dock = System.Windows.Forms.DockStyle.Fill;
		this.tView.Font = new System.Drawing.Font("맑은 고딕", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 129);
		this.tView.Location = new System.Drawing.Point(0, 83);
		this.tView.Name = "tView";
		this.tView.Size = new System.Drawing.Size(291, 561);
		this.tView.TabIndex = 0;
		this.panel2.Controls.Add(this.chbM);
		this.panel2.Controls.Add(this.chbD);
		this.panel2.Controls.Add(this.chbA);
		this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
		this.panel2.Location = new System.Drawing.Point(0, 44);
		this.panel2.Name = "panel2";
		this.panel2.Size = new System.Drawing.Size(291, 39);
		this.panel2.TabIndex = 25;
		this.chbM.Font = new System.Drawing.Font("맑은 고딕", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 129);
		this.chbM.Location = new System.Drawing.Point(66, 10);
		this.chbM.Name = "chbM";
		this.chbM.Size = new System.Drawing.Size(69, 21);
		this.chbM.TabIndex = 23;
		this.chbM.Text = "Master";
		this.chbM.UseVisualStyleBackColor = true;
		this.chbM.CheckedChanged += new System.EventHandler(chb_CheckedChanged);
		this.chbD.Font = new System.Drawing.Font("맑은 고딕", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 129);
		this.chbD.Location = new System.Drawing.Point(139, 10);
		this.chbD.Name = "chbD";
		this.chbD.Size = new System.Drawing.Size(55, 21);
		this.chbD.TabIndex = 24;
		this.chbD.Text = "Data";
		this.chbD.UseVisualStyleBackColor = true;
		this.chbD.CheckedChanged += new System.EventHandler(chb_CheckedChanged);
		this.chbA.Font = new System.Drawing.Font("맑은 고딕", 9.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 129);
		this.chbA.Location = new System.Drawing.Point(15, 10);
		this.chbA.Name = "chbA";
		this.chbA.Size = new System.Drawing.Size(47, 21);
		this.chbA.TabIndex = 2;
		this.chbA.Text = "All";
		this.chbA.UseVisualStyleBackColor = true;
		this.chbA.CheckedChanged += new System.EventHandler(chb_CheckedChanged);
		this.lblMySql.Dock = System.Windows.Forms.DockStyle.Top;
		this.lblMySql.Font = new System.Drawing.Font("맑은 고딕", 12f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 129);
		this.lblMySql.Location = new System.Drawing.Point(0, 0);
		this.lblMySql.Name = "lblMySql";
		this.lblMySql.Size = new System.Drawing.Size(291, 44);
		this.lblMySql.TabIndex = 1;
		this.lblMySql.Text = "Tables";
		this.lblMySql.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.button3.Font = new System.Drawing.Font("맑은 고딕", 11.25f);
		this.button3.Location = new System.Drawing.Point(471, 77);
		this.button3.Name = "button3";
		this.button3.Size = new System.Drawing.Size(141, 29);
		this.button3.TabIndex = 22;
		this.button3.Text = "File ->PMK";
		this.button3.UseVisualStyleBackColor = true;
		this.button3.Click += new System.EventHandler(button3_Click);
		this.button2.Font = new System.Drawing.Font("맑은 고딕", 11.25f);
		this.button2.Location = new System.Drawing.Point(330, 77);
		this.button2.Name = "button2";
		this.button2.Size = new System.Drawing.Size(141, 29);
		this.button2.TabIndex = 21;
		this.button2.Text = "IRIS -> File";
		this.button2.UseVisualStyleBackColor = true;
		this.button2.Click += new System.EventHandler(button2_Click);
		this.label3.AutoSize = true;
		this.label3.Font = new System.Drawing.Font("맑은 고딕", 11.25f);
		this.label3.Location = new System.Drawing.Point(42, 80);
		this.label3.Name = "label3";
		this.label3.Size = new System.Drawing.Size(50, 20);
		this.label3.TabIndex = 20;
		this.label3.Text = "Server";
		this.label3.Visible = false;
		this.radioButton1.AutoSize = true;
		this.radioButton1.Checked = true;
		this.radioButton1.Font = new System.Drawing.Font("맑은 고딕", 11.25f);
		this.radioButton1.Location = new System.Drawing.Point(98, 78);
		this.radioButton1.Name = "radioButton1";
		this.radioButton1.Size = new System.Drawing.Size(56, 24);
		this.radioButton1.TabIndex = 18;
		this.radioButton1.TabStop = true;
		this.radioButton1.Tag = "";
		this.radioButton1.Text = "DEV";
		this.radioButton1.UseVisualStyleBackColor = true;
		this.radioButton1.Visible = false;
		this.radioButton1.CheckedChanged += new System.EventHandler(rb_CheckedChanged);
		this.radioButton2.AutoSize = true;
		this.radioButton2.Font = new System.Drawing.Font("맑은 고딕", 11.25f);
		this.radioButton2.Location = new System.Drawing.Point(160, 78);
		this.radioButton2.Name = "radioButton2";
		this.radioButton2.Size = new System.Drawing.Size(56, 24);
		this.radioButton2.TabIndex = 19;
		this.radioButton2.Tag = "";
		this.radioButton2.Text = "PRD";
		this.radioButton2.UseVisualStyleBackColor = true;
		this.radioButton2.Visible = false;
		this.radioButton2.CheckedChanged += new System.EventHandler(rb_CheckedChanged);
		this.dgv.AllowUserToAddRows = false;
		this.dgv.AllowUserToDeleteRows = false;
		this.dgv.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
		this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
		this.dgv.BackgroundColor = System.Drawing.SystemColors.ControlLight;
		this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
		this.dgv.Location = new System.Drawing.Point(4, 110);
		this.dgv.Name = "dgv";
		this.dgv.ReadOnly = true;
		this.dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
		this.dgv.Size = new System.Drawing.Size(614, 531);
		this.dgv.TabIndex = 14;
		this.button1.Font = new System.Drawing.Font("맑은 고딕", 11.25f);
		this.button1.Location = new System.Drawing.Point(330, 47);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(282, 29);
		this.button1.TabIndex = 13;
		this.button1.Text = "IRIS -> PMK";
		this.button1.UseVisualStyleBackColor = true;
		this.button1.Click += new System.EventHandler(button1_Click);
		this.lblMSSql.BackColor = System.Drawing.Color.White;
		this.lblMSSql.Dock = System.Windows.Forms.DockStyle.Top;
		this.lblMSSql.Font = new System.Drawing.Font("맑은 고딕", 12f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 129);
		this.lblMSSql.Location = new System.Drawing.Point(0, 0);
		this.lblMSSql.Name = "lblMSSql";
		this.lblMSSql.Size = new System.Drawing.Size(622, 40);
		this.lblMSSql.TabIndex = 12;
		this.lblMSSql.Text = "MSSQL";
		this.lblMSSql.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		this.dateFrom.CustomFormat = "yyyy-MM-dd";
		this.dateFrom.Font = new System.Drawing.Font("맑은 고딕", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.dateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
		this.dateFrom.Location = new System.Drawing.Point(96, 47);
		this.dateFrom.Name = "dateFrom";
		this.dateFrom.Size = new System.Drawing.Size(100, 27);
		this.dateFrom.TabIndex = 8;
		this.label4.AutoSize = true;
		this.label4.Font = new System.Drawing.Font("맑은 고딕", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.label4.Location = new System.Drawing.Point(198, 51);
		this.label4.Name = "label4";
		this.label4.Size = new System.Drawing.Size(20, 20);
		this.label4.TabIndex = 11;
		this.label4.Text = "~";
		this.dateTo.CustomFormat = "yyyy-MM-dd";
		this.dateTo.Font = new System.Drawing.Font("맑은 고딕", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.dateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
		this.dateTo.Location = new System.Drawing.Point(221, 47);
		this.dateTo.Name = "dateTo";
		this.dateTo.Size = new System.Drawing.Size(100, 27);
		this.dateTo.TabIndex = 9;
		this.label5.AutoSize = true;
		this.label5.Font = new System.Drawing.Font("맑은 고딕", 11.25f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		this.label5.Location = new System.Drawing.Point(7, 51);
		this.label5.Name = "label5";
		this.label5.Size = new System.Drawing.Size(101, 20);
		this.label5.TabIndex = 10;
		this.label5.Text = "update,create";
		this.panel1.BackColor = System.Drawing.Color.White;
		this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
		this.panel1.Controls.Add(this.label1);
		this.panel1.Controls.Add(this.label2);
		this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
		this.panel1.Font = new System.Drawing.Font("맑은 고딕", 12f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 129);
		this.panel1.Location = new System.Drawing.Point(0, 0);
		this.panel1.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
		this.panel1.Name = "panel1";
		this.panel1.Size = new System.Drawing.Size(924, 57);
		this.panel1.TabIndex = 1;
		this.label1.AutoSize = true;
		this.label1.Font = new System.Drawing.Font("맑은 고딕", 24f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 129);
		this.label1.Location = new System.Drawing.Point(16, 5);
		this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
		this.label1.Name = "label1";
		this.label1.Size = new System.Drawing.Size(127, 45);
		this.label1.TabIndex = 0;
		this.label1.Text = "* TITLE";
		this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right;
		this.label2.AutoSize = true;
		this.label2.Font = new System.Drawing.Font("맑은 고딕", 15.75f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 129);
		this.label2.Location = new System.Drawing.Point(778, 19);
		this.label2.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
		this.label2.Name = "label2";
		this.label2.Size = new System.Drawing.Size(139, 30);
		this.label2.TabIndex = 1;
		this.label2.Text = "[1579-01-01]";
		this.cbEncript.AutoSize = true;
		this.cbEncript.Location = new System.Drawing.Point(265, 82);
		this.cbEncript.Name = "cbEncript";
		this.cbEncript.Size = new System.Drawing.Size(66, 21);
		this.cbEncript.TabIndex = 26;
		this.cbEncript.Text = "암호화";
		this.cbEncript.UseVisualStyleBackColor = true;
		base.AutoScaleDimensions = new System.Drawing.SizeF(16f, 37f);
		base.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		base.ClientSize = new System.Drawing.Size(924, 701);
		base.Controls.Add(this.splitContainer1);
		base.Controls.Add(this.panel1);
		this.Font = new System.Drawing.Font("맑은 고딕", 20.25f, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
		base.Margin = new System.Windows.Forms.Padding(8, 9, 8, 9);
		base.Name = "Form2";
		this.Text = "PMK_IRISGetData - v1.1.0.0";
		base.Load += new System.EventHandler(Form2_Load);
		this.splitContainer1.Panel1.ResumeLayout(false);
		this.splitContainer1.Panel2.ResumeLayout(false);
		this.splitContainer1.Panel2.PerformLayout();
		((System.ComponentModel.ISupportInitialize)this.splitContainer1).EndInit();
		this.splitContainer1.ResumeLayout(false);
		this.panel2.ResumeLayout(false);
		((System.ComponentModel.ISupportInitialize)this.dgv).EndInit();
		this.panel1.ResumeLayout(false);
		this.panel1.PerformLayout();
		base.ResumeLayout(false);
	}
}
