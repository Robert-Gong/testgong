using System;
using System.Configuration;
using System.IO;

namespace PMK.Common;

public class LogFile
{
	public static void WriteLog(Exception ex)
	{
		WriteLog("", ex);
	}

	public static void WriteLog(string msg)
	{
		WriteLog(msg, null);
	}

	public static void WriteLog(string msg, Exception ex)
	{
		try
		{
			string text = ConfigurationManager.AppSettings["LogPath"];
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			string path = text + DateTime.Now.ToString("yyyyMM") + ".log";
			using StreamWriter streamWriter = new StreamWriter(path, append: true);
			if (ex != null)
			{
				streamWriter.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]") + "[Source   ] " + ex.Source.ToString());
				streamWriter.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]") + "[Message  ] " + ex.Message);
				streamWriter.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]") + "[Location ] " + ex.StackTrace);
			}
			else
			{
				streamWriter.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]") + msg);
			}
			streamWriter.Close();
		}
		catch
		{
		}
	}
}
