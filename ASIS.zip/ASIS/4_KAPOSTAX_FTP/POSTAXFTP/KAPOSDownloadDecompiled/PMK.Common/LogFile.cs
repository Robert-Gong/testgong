using System;
using System.Configuration;
using System.IO;

namespace PMK.Common;

/// <summary>
/// 애플리케이션의 로그를 파일에 기록하는 유틸리티 클래스
/// 예외 정보와 일반 메시지를 날짜별 로그 파일에 저장함
/// </summary>
public class LogFile
{
	/// <summary>
	/// 로그 파일명에 사용될 시스템 이름
	/// 생성되는 로그 파일은 이 이름을 포함하여 구분됨
	/// </summary>
	private static string strSystemName = "KAPOSDownload";

	/// <summary>
	/// 예외 정보만을 로그 파일에 기록
	/// </summary>
	/// <param name="ex">기록할 예외 객체</param>
	public static void WriteLog(Exception ex)
	{
		WriteLog("", ex);
	}

	/// <summary>
	/// 문자열 메시지만을 로그 파일에 기록
	/// </summary>
	/// <param name="msg">기록할 메시지</param>
	public static void WriteLog(string msg)
	{
		WriteLog(msg, null);
	}

	/// <summary>
	/// 메시지와 예외 정보를 모두 로그 파일에 기록하는 메인 메소드
	/// </summary>
	/// <param name="msg">기록할 메시지</param>
	/// <param name="ex">기록할 예외 객체 (선택사항)</param>
	public static void WriteLog(string msg, Exception ex)
	{
		try
		{
			// 설정 파일에서 로그 저장 경로를 가져옴
			string text = ConfigurationManager.AppSettings["LogPath"];
			// 로그 디렉토리가 존재하지 않으면 생성
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			// 로그 파일명 생성: 경로 + 시스템명 + 날짜(yyyyMMdd) + .log
			string path = text + strSystemName + DateTime.Now.ToString("yyyyMMdd") + ".log";
			// 로그 파일을 추가 모드로 열기
			using StreamWriter streamWriter = new StreamWriter(path, append: true);
			// 예외 객체가 있는 경우 예외 정보를 자세히 기록
			if (ex != null)
			{
				// 예외가 발생한 소스 정보 기록
				streamWriter.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]") + "[Source   ] " + ex.Source.ToString());
				// 예외 메시지 기록
				streamWriter.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]") + "[Message  ] " + ex.Message);
				// 예외 발생 위치의 스택 트레이스 기록
				streamWriter.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]") + "[Location ] " + ex.StackTrace);
			}
			else
			{
				// 일반 메시지인 경우 시간과 함께 기록
				streamWriter.WriteLine(DateTime.Now.ToString("[yyyyMMdd HH:mm:ss]") + msg);
			}
			streamWriter.Close();
		}
		catch
		{
		}
	}
}
