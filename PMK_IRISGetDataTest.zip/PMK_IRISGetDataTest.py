import os
import logging
import boto3
import pyodbc
import pandas as pd
import xml.etree.ElementTree as ET
import xml.dom.minidom as minidom
from datetime import datetime, timedelta
from Crypto.Cipher import DES
from Crypto.Util.Padding import pad

# ================================
# App.config 값 하드코딩
# ================================
LOG_PATH = "Tools/IRIS/Log"
DATA_FILE_PATH = "sFTP_POS/POS_Data/POS_OTHERS"
DBSERVER = "DEV"  # DEV / QA / PRD

# ================================
# DB 연결 (MSSQLConStr 대응)
# ================================
if DBSERVER == "PRD":
    DB_HOST = "211.50.136.35"
    DB_PORT = "1433"  # PRD는 포트 다를 수 있음 (C#에서 따로 지정)
    DB_NAME = "corner_shop"
    DB_USER = "pmk_sales"
    DB_PASSWORD = "pmk123$$"
else:
    DB_HOST = "211.50.136.35"
    DB_PORT = "9433"
    DB_NAME = "corner_shop"
    DB_USER = "sa"
    DB_PASSWORD = "qwer!234"

# ================================
# S3 (Lambda 용)
# ================================
S3_BUCKET_NAME = "kihub-transfer-bucket-dev"
S3_REGION = "ap-southeast-1"

# DES 암호화 키 (C# 동일)
KEY = b"\x6b\x6c\x6d\x6e\x6e\x6d\x6c\x6b"
IV = KEY  # IV = Key

# ================================
# 로거
# ================================
logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client("s3", region_name=S3_REGION)

# ================================
# 테이블 목록
# ================================
TABLES_DICT = {
    "categories": "M", "characters": "M", "common_d": "M", "coupons": "D",
    "discounts": "M", "order_products": "D", "orders": "D", "product_categories": "M",
    "products": "M", "shop_branches": "M", "shop_groups": "M", "shops": "M",
    "visitor_characters": "D", "consumed_coupons": "D", "callcard_ans_grp_d": "M",
    "callcard_ans_grp_h": "M", "callcard_ans_tp": "M", "callcard_answers": "D",
    "callcard_apply_shop": "M", "callcard_mst_d": "M", "callcard_mst_h": "M",
    "order_coupon": "D", "consumer": "D", "timestamps_fcm": "M", "timestamps": "D",
    "characters_q": "M", "characters_a": "M", "visitor_characters_new": "D",
    "visitors": "D", "performances": "D", "hashtag": "M", "hashtag_product": "M",
    "shop_branch_sf": "M"
}

# ================================
# 암호화 함수 (C# ToEncryptFile 대응)
# ================================
def encrypt_data(data: str) -> bytes:
    try:
        cipher = DES.new(KEY, DES.MODE_CBC, IV)
        padded = pad(data.encode("utf-8"), DES.block_size)
        return cipher.encrypt(padded)
    except Exception as e:
        logger.error(f"데이터 암호화 오류: {e}")
        raise

# ================================
# DataFrame → XML 변환
# ================================
def df_to_xml_string(df, root_tag="root", row_tag="row") -> str:
    root = ET.Element(root_tag)
    for _, row in df.iterrows():
        row_elem = ET.SubElement(root, row_tag)
        for col, val in row.items():
            col_elem = ET.SubElement(row_elem, col)
            col_elem.text = str(val)
    xml_bytes = ET.tostring(root, encoding="utf-8")
    dom = minidom.parseString(xml_bytes)
    return dom.toprettyxml(indent="  ")

# ================================
# S3 저장 (C# SaveFile 대응)
# ================================
def save_file_to_s3(df, tbname, dateF, dateT, encrypt=True):
    try:
        # Schema 파일
        schema_key = f"{DATA_FILE_PATH}/PMKIRIS#{tbname}#{dateF}#{dateT}#schema.xml"
        schema_root = ET.Element("Schema")
        for col in df.columns:
            ET.SubElement(schema_root, "Column").set("Name", col)
        schema_xml = ET.tostring(schema_root, encoding="utf-8").decode("utf-8")

        if encrypt:
            schema_xml = encrypt_data(schema_xml)

        s3_client.put_object(Bucket=S3_BUCKET_NAME, Key=schema_key, Body=schema_xml)

        # Data 파일
        data_key = f"{DATA_FILE_PATH}/PMKIRIS#{tbname}#{dateF}#{dateT}#data.xml"
        data_xml = df_to_xml_string(df, "root", "row")

        if encrypt:
            data_xml = encrypt_data(data_xml)

        s3_client.put_object(Bucket=S3_BUCKET_NAME, Key=data_key, Body=data_xml)

        logger.info(f"[IRIS] [{dateF}] [{tbname}] 파일 저장 완료")

    except Exception as e:
        logger.error(f"[IRIS ERROR] save_file_to_s3() - [{tbname}]")
        logger.error(e)
        raise

# ================================
# AUTOGET (C# Form2.AUTOGET)
# ================================
def autoget():
    logger.info("[IRIS START] AUTOGET() ################################")
    # conn_str = (
    #     f"DRIVER={{ODBC Driver 17 for SQL Server}};"
    #     f"SERVER={DB_HOST},{DB_PORT};"
    #     f"DATABASE={DB_NAME};"
    #     f"UID={DB_USER};"
    #     f"PWD={DB_PASSWORD};"
    # )
    # conn = None
    # try:
    #     conn = pyodbc.connect(conn_str)
    #     today = (datetime.now() - timedelta(days=1)).strftime("%Y%m%d")

    #     for tbname, ttype in TABLES_DICT.items():
    #         try:
    #             if ttype == "M":
    #                 query = f"SELECT * FROM iris.{tbname}"
    #             else:
    #                 query = (
    #                     f"SELECT * FROM iris.{tbname} "
    #                     f"WHERE (CONVERT(VARCHAR(8), updated_at, 112) = '{today}') "
    #                     f"OR (CONVERT(VARCHAR(8), created_at, 112) = '{today}')"
    #                 )
    #             logger.info(f"[{tbname}] 쿼리 실행: {query}")
    #             df = pd.read_sql(query, conn)
    #             if not df.empty:
    #                 save_file_to_s3(df, tbname, today, today, encrypt=True)
    #             else:
    #                 logger.info(f"[{tbname}] 데이터 없음")
    #         except Exception as ex:
    #             logger.error(f"[IRIS ERROR] AUTOGET() - [{tbname}]")
    #             logger.error(ex)

    # except Exception as e:
    #     logger.error("[IRIS ERROR] AUTOGET() - DB 연결 실패")
    #     logger.error(e)
    # finally:
    #     if conn:
    #         conn.close()
    
    # DB 대신 가짜 데이터 생성
    df = pd.DataFrame([
        {"id": 1, "name": "Alice", "created_at": "2024-09-01"},
        {"id": 2, "name": "Bob", "created_at": "2024-09-02"}
    ])
    
    # 기존 save_file_to_s3 로직 재사용
    save_file_to_s3(df, "test_table", "20240901", "20240902", encrypt=True)
    logger.info("[IRIS END] AUTOGET() ##################################")

# ================================
# Lambda 핸들러
# ================================
def lambda_handler(event, context):
    action = event.get("action", "AUTOGET")
    if action == "AUTOGET":
        autoget()
        return {"statusCode": 200, "body": "AUTOGET completed"}
    else:
        return {"statusCode": 400, "body": "지원하지 않는 action"}
